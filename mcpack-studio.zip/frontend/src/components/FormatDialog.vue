<template>
  <Transition name="modal">
    <Teleport to="body">
      <div class="modal-overlay" @click.self="cancel">
        <div class="modal">
          <div class="modal-header">
            <span>Format Text...</span>
            <button class="btn-close" @click="cancel">✕</button>
          </div>

        <div class="modal-body">
          <div class="field-block">
            <label>Text:</label>
            <input ref="textInput" v-model="localText" type="text" class="text-input" @input="updatePreview" />
          </div>

          <div class="field-block">
            <label>Preview:</label>
            <div class="preview-box">
              <span v-for="(span, i) in spans" :key="i"
                :style="{
                  color: span.colour,
                  fontWeight: span.bold ? 'bold' : 'normal',
                  fontStyle: span.italic ? 'italic' : 'normal',
                  textDecoration: [span.strike ? 'line-through' : '', span.under ? 'underline' : ''].filter(Boolean).join(' ') || 'none',
                  filter: span.obfusc ? 'blur(3px)' : 'none',
                }"
              >{{ span.text }}</span>
              <span v-if="!localText" class="preview-placeholder">Preview</span>
            </div>
          </div>

          <div class="field-block">
            <label>Colours:</label>
            <div class="colour-grid">
              <button
                v-for="c in COLOURS" :key="c.code"
                type="button"
                class="colour-btn"
                :style="{ background: c.bg, color: c.fg }"
                :title="'§' + c.code + ' ' + c.bg"
                @click="insert(c.code)"
              >{{ c.label }}</button>
            </div>
          </div>

          <div class="field-block">
            <label>Styles:</label>
            <div class="style-row">
              <button v-for="s in STYLES" :key="s.code"
                type="button" class="style-btn"
                :style="s.css"
                :title="'§' + s.code + ' — ' + s.tip"
                @click="insert(s.code)"
              >{{ s.label }}</button>
            </div>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-cancel" @click="cancel">✕  Cancel</button>
          <button type="button" class="btn-ok" @click="confirm">✔  OK</button>
        </div>
      </div>
      </div>
    </Teleport>
  </Transition>
</template>

<script setup>
import { ref, watch, nextTick, onMounted } from 'vue'

const props = defineProps({
  modelValue: { type: String, default: '' },
})
const emit = defineEmits(['update:modelValue', 'close'])

const textInput = ref(null)
const localText = ref(props.modelValue)
const spans     = ref([])

const COLOURS = [
  { code:'0', label:'0', bg:'#000000', fg:'#ffffff' },
  { code:'1', label:'1', bg:'#0000AA', fg:'#ffffff' },
  { code:'2', label:'2', bg:'#00AA00', fg:'#ffffff' },
  { code:'3', label:'3', bg:'#00AAAA', fg:'#ffffff' },
  { code:'4', label:'4', bg:'#AA0000', fg:'#ffffff' },
  { code:'5', label:'5', bg:'#AA00AA', fg:'#ffffff' },
  { code:'6', label:'6', bg:'#FFAA00', fg:'#000000' },
  { code:'7', label:'7', bg:'#AAAAAA', fg:'#000000' },
  { code:'8', label:'8', bg:'#555555', fg:'#ffffff' },
  { code:'9', label:'9', bg:'#5555FF', fg:'#ffffff' },
  { code:'a', label:'a', bg:'#55FF55', fg:'#000000' },
  { code:'b', label:'b', bg:'#55FFFF', fg:'#000000' },
  { code:'c', label:'c', bg:'#FF5555', fg:'#000000' },
  { code:'d', label:'d', bg:'#FF55FF', fg:'#000000' },
  { code:'e', label:'e', bg:'#FFFF55', fg:'#000000' },
  { code:'f', label:'f', bg:'#FFFFFF', fg:'#000000' },
]

const COLOUR_MAP = Object.fromEntries(COLOURS.map(c => [c.code, c.bg]))

const STYLES = [
  { code:'l', label:'B',  tip:'Bold',          css:{ fontWeight:'bold' } },
  { code:'o', label:'I',  tip:'Italic',         css:{ fontStyle:'italic' } },
  { code:'m', label:'S',  tip:'Strikethrough',  css:{ textDecoration:'line-through' } },
  { code:'n', label:'U',  tip:'Underline',      css:{ textDecoration:'underline' } },
  { code:'k', label:'✦', tip:'Obfuscated',     css:{} },
  { code:'r', label:'R',  tip:'Reset',          css:{ color:'#e07b00', fontWeight:'bold' } },
]

function parseSpans(text) {
  const parts = text.split(/(§.)/g)
  let colour = '#ffffff', bold = false, italic = false
  let strike = false, under = false, obfusc = false
  const result = []
  for (const part of parts) {
    if (part.length === 2 && part[0] === '§') {
      const code = part[1].toLowerCase()
      if (COLOUR_MAP[code]) {
        colour = COLOUR_MAP[code]
        bold = italic = strike = under = obfusc = false
      } else if (code === 'l') bold   = true
      else if (code === 'o')   italic = true
      else if (code === 'm')   strike = true
      else if (code === 'n')   under  = true
      else if (code === 'k')   obfusc = true
      else if (code === 'r') {
        colour = '#ffffff'
        bold = italic = strike = under = obfusc = false
      }
    } else if (part) {
      result.push({ text: part, colour, bold, italic, strike, under, obfusc })
    }
  }
  return result
}

function updatePreview() {
  spans.value = parseSpans(localText.value)
}

function insert(code) {
  const el = textInput.value
  const pos = el.selectionStart ?? localText.value.length
  localText.value = localText.value.slice(0, pos) + '§' + code + localText.value.slice(pos)
  updatePreview()
  nextTick(() => {
    el.focus()
    el.setSelectionRange(pos + 2, pos + 2)
  })
}

function confirm() {
  emit('update:modelValue', localText.value)
  emit('close')
}
function cancel() { emit('close') }

onMounted(() => {
  updatePreview()
  nextTick(() => textInput.value?.focus())
})
</script>

<style scoped>
.modal-overlay {
  position: fixed; inset: 0;
  background: rgba(15,23,42,0.5);
  backdrop-filter: blur(4px);
  display: flex; align-items: center; justify-content: center; z-index: 1000;
}

.modal-enter-active { transition: opacity 0.25s ease; }
.modal-leave-active { transition: opacity 0.2s ease; }
.modal-enter-active .modal { transition: transform 0.25s ease, opacity 0.25s ease; }
.modal-leave-active .modal { transition: transform 0.15s ease, opacity 0.15s ease; }
.modal-enter-from, .modal-leave-to { opacity: 0; }
.modal-enter-from .modal { transform: scale(0.95) translateY(10px); opacity: 0; }
.modal-leave-to .modal { transform: scale(0.95); opacity: 0; }
.modal {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  box-shadow: 0 20px 40px rgba(0,0,0,0.15), 0 0 0 1px rgba(0,0,0,0.05);
  width: 460px; max-width: 95vw;
  display: flex; flex-direction: column;
}
.modal-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 18px; border-bottom: 1px solid var(--border);
  font-size: 0.88rem; font-weight: 600; background: var(--bg3);
  border-radius: var(--radius-lg) var(--radius-lg) 0 0;
}
.btn-close {
  background: none; border: none; color: var(--text3);
  cursor: pointer; font-size: 0.78rem; padding: 3px 7px;
  border-radius: 6px; transition: color 0.15s, background 0.15s;
}
.btn-close:hover { color: var(--red); background: color-mix(in srgb, var(--red) 8%, transparent); }

.modal-body { padding: 16px 18px; display: flex; flex-direction: column; gap: 14px; }

.field-block { display: flex; flex-direction: column; gap: 5px; }
.field-block label {
  font-size: 0.7rem; font-weight: 600;
  letter-spacing: 0.06em; text-transform: uppercase; color: var(--text3);
}

.text-input {
  background: var(--bg-input); border: 1px solid var(--border2);
  border-radius: var(--radius); color: var(--text);
  font-family: var(--font); font-size: 0.88rem;
  padding: 7px 10px; outline: none; box-shadow: var(--shadow-sm);
  transition: border-color 0.15s, box-shadow 0.15s;
}
.text-input:focus {
  border-color: var(--border-focus);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent) 15%, transparent);
}

.preview-box {
  background: #1e293b; border: 1px solid #334155;
  border-radius: var(--radius); padding: 8px 12px; min-height: 36px;
  font-size: 0.9rem; font-family: 'Courier New', monospace;
  display: flex; align-items: center; flex-wrap: wrap;
}
.preview-placeholder { color: #475569; font-style: italic; }

.colour-grid { display: grid; grid-template-columns: repeat(8, 1fr); gap: 3px; }
.colour-btn {
  border: 1px solid transparent; border-radius: 4px;
  font-size: 0.75rem; font-weight: 700;
  padding: 5px 2px; cursor: pointer; line-height: 1;
  transition: transform 0.1s, box-shadow 0.1s;
}
.colour-btn:hover { transform: scale(1.08); box-shadow: 0 2px 6px rgba(0,0,0,0.2); }

.style-row { display: flex; gap: 5px; }
.style-btn {
  background: var(--bg3); border: 1px solid var(--border2);
  border-radius: var(--radius); color: var(--text2);
  font-family: var(--font); font-size: 0.82rem;
  padding: 5px 12px; cursor: pointer; min-width: 36px;
  transition: border-color 0.15s, color 0.15s, background 0.15s;
}
.style-btn:hover { border-color: var(--accent); color: var(--accent); background: var(--accent-light); }

.modal-footer {
  display: flex; justify-content: flex-end; gap: 8px;
  padding: 12px 18px; border-top: 1px solid var(--border);
  background: var(--bg3);
  border-radius: 0 0 var(--radius-lg) var(--radius-lg);
}
.btn-cancel, .btn-ok {
  border-radius: var(--radius); font-family: var(--font);
  font-size: 0.82rem; font-weight: 500; padding: 7px 18px; cursor: pointer;
}
.btn-cancel {
  background: var(--bg-input); border: 1px solid var(--border2); color: var(--text2);
}
.btn-cancel:hover { border-color: var(--accent); color: var(--accent); background: var(--accent-light); }
.btn-ok {
  background: var(--accent); border: none; color: #fff;
  box-shadow: 0 1px 2px rgba(99,102,241,0.3);
}
.btn-ok:hover { background: var(--accent-hover); }
</style>
