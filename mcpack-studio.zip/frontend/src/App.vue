<template>
  <div class="app">
    <!-- Loading screen -->
    <Transition name="fade">
      <div v-if="isLoading" class="loading-screen">
        <div class="loading-content">
          <div class="loading-logo">
            <svg width="32" height="32" viewBox="0 0 20 20" fill="none">
              <path d="M10 2L17.32 6.5V15.5L10 20L2.68 15.5V6.5L10 2Z" fill="currentColor" opacity="0.15"/>
              <path d="M10 2L17.32 6.5V15.5L10 20L2.68 15.5V6.5L10 2Z" stroke="currentColor" stroke-width="1.5"/>
            </svg>
          </div>
          <div class="loading-spinner"></div>
          <p class="loading-text">Loading Extension Studio...</p>
        </div>
      </div>
    </Transition>

    <header class="app-header">
      <div class="header-inner">
        <div class="logo">
          <img class="logo-mark" src="https://www.dropbox.com/scl/fi/yymr5hnfkko77aaxadjta/logo_bigger.png?rlkey=gicau4lxtbbhmq9vt2reyrk8c&st=kvv7wolj&dl=1" alt="Logo" />
          <span class="logo-text">Extension <strong>Studio</strong></span>
        </div>

        <div class="header-actions">
          <SettingsDropdown @update:settings="onSettings" />

          <button class="hdr-btn" @click="showAbout = true">About</button>
        </div>
      </div>
    </header>

    <!-- Active build banner (shown on page reload if build is in progress) -->
    <Transition name="toast">
      <div v-if="activeBuild" class="active-build-banner">
        <div class="ab-left">
          <span class="ab-dot"></span>
          <div>
            <p class="ab-title">A build is currently in progress</p>
            <p class="ab-sub">Resuming will reconnect to the build log. Dismissing will leave the process running — the output file will be lost if not downloaded.</p>
          </div>
        </div>
        <div class="ab-actions">
          <button class="ab-btn-resume" @click="resumeBuild(activeBuild)">Resume</button>
          <button class="ab-btn-dismiss" @click="dismissActiveBuild">Dismiss</button>
        </div>
      </div>
    </Transition>

    <!-- Open result toast -->
    <Transition name="toast">
      <div v-if="openToast" class="open-toast" :class="openToast.type">
        {{ openToast.msg }}
      </div>
    </Transition>

    <main class="app-main">
      <div class="layout" :class="{ 'layout-single': !isBuilding && !downloadReady && !buildError && !taskId && !appSettings.showBuildLogs }">
        <section class="card">
          <BuildForm
            ref="buildFormRef"
            @submitted="onSubmitted"
            :disabled="isBuilding"
            :debug="appSettings.debugLogs"
          />
        </section>

        <div class="sidebar" v-if="isBuilding || downloadReady || buildError || taskId || appSettings.showBuildLogs">
          <section class="card" v-if="appSettings.showBuildLogs !== false">
            <ProgressPanel
              :task-id="taskId"
              :is-building="isBuilding"
                @done="onDone"
              @error="onError"
            />
          </section>
          <DownloadCard
            v-if="downloadReady || buildError"
            :task-id="taskId"
            :error="buildError"
            :file-ext="currentEdition === 'java' ? 'zip' : 'mcpack'"
            @reset="onReset"
          />
        </div>
      </div>
    </main>

    <AboutDialog v-if="showAbout" @close="showAbout = false" />
    <AnnouncementBanner />
    <Fireworks />
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import BuildForm      from './components/BuildForm.vue'
import ProgressPanel  from './components/ProgressPanel.vue'
import DownloadCard   from './components/DownloadCard.vue'
import AboutDialog    from './components/AboutDialog.vue'
import SettingsDropdown from './components/SettingsDropdown.vue'
import AnnouncementBanner from './components/AnnouncementBanner.vue'
import Fireworks from './components/Fireworks.vue'
import { prefetchBanner } from './composables/useBanner'

const taskId        = ref(null)
const isLoading     = ref(true)
const isBuilding    = ref(false)
const downloadReady = ref(false)
const buildError    = ref(null)
const showAbout     = ref(false)
const buildFormRef  = ref(null)
const appSettings   = reactive({ showBuildLogs: true, debugLogs: false })
const openToast     = ref(null)
const currentEdition = ref('bedrock')

let _toastTimer = null

// ── Active build detection on page load ───────────────────────────────────
const activeBuild = ref(null)   // { task_id, progress } | null

onMounted(async () => {
  prefetchBanner()

  await new Promise(r => setTimeout(r, 800))

  try {
    const res = await fetch('/api/status/active')
    if (!res.ok) return
    const data = await res.json()
    if (data.running && data.running.length > 0) {
      activeBuild.value = data.running[0]
    }
  } catch {}
  isLoading.value = false
})

function resumeBuild(task) {
  activeBuild.value = null
  taskId.value       = task.task_id
  isBuilding.value   = true
  downloadReady.value = false
  buildError.value   = null
}

function dismissActiveBuild() {
  activeBuild.value = null
}

function onSettings(s) { Object.assign(appSettings, s) }

function onSubmitted(payload) {
  const id      = payload?.taskId ?? payload
  const edition = payload?.edition ?? 'bedrock'
  taskId.value = id; isBuilding.value = true
  downloadReady.value = false; buildError.value = null
  currentEdition.value = edition
}
function onDone()     { isBuilding.value = false; downloadReady.value = true }
function onError(msg) { isBuilding.value = false; buildError.value = msg }
function onReset()    {
  taskId.value = null; isBuilding.value = false
  downloadReady.value = false; buildError.value = null
}

function showToast(msg, type = 'info') {
  clearTimeout(_toastTimer)
  openToast.value = { msg, type }
  _toastTimer = setTimeout(() => { openToast.value = null }, 4000)
}
</script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg:          #f8fafc;
  --bg2:         #ffffff;
  --bg3:         #f1f5f9;
  --bg-input:    #ffffff;
  --border:      #e2e8f0;
  --border2:     #cbd5e1;
  --border-focus:#6366f1;
  --accent:      #6366f1;
  --accent-hover:#4f46e5;
  --accent-light:#eef2ff;
  --green:       #10b981;
  --amber:       #f59e0b;
  --red:         #ef4444;
  --text:        #0f172a;
  --text2:       #475569;
  --text3:       #94a3b8;
  --shadow-sm:   0 1px 2px rgba(0,0,0,0.05);
  --shadow:      0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04);
  --shadow-md:   0 4px 6px rgba(0,0,0,0.06), 0 2px 4px rgba(0,0,0,0.04);
  --font:        'Inter', sans-serif;
  --mono:        'JetBrains Mono', monospace;
  --radius:      8px;
  --radius-lg:   12px;
}

[data-theme="dark"] {
  --bg:          #0f172a;
  --bg2:         #1e293b;
  --bg3:         #0f172a;
  --bg-input:    #1e293b;
  --border:      #334155;
  --border2:     #475569;
  --border-focus:#818cf8;
  --accent:      #818cf8;
  --accent-hover:#6366f1;
  --accent-light:#1e1b4b;
  --green:       #34d399;
  --amber:      #fbbf24;
  --red:         #f87171;
  --text:        #f1f5f9;
  --text2:       #94a3b8;
  --text3:       #475569;
  --shadow-sm:   0 1px 2px rgba(0,0,0,0.3);
  --shadow:      0 1px 3px rgba(0,0,0,0.4);
  --shadow-md:   0 4px 6px rgba(0,0,0,0.4);
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme]) {
    --bg:          #0f172a;
    --bg2:         #1e293b;
    --bg3:         #0f172a;
    --bg-input:    #1e293b;
    --border:      #334155;
    --border2:     #475569;
    --border-focus:#818cf8;
    --accent:      #818cf8;
    --accent-hover:#6366f1;
    --accent-light:#1e1b4b;
    --green:       #34d399;
    --amber:      #fbbf24;
    --red:         #f87171;
    --text:        #f1f5f9;
    --text2:       #94a3b8;
    --text3:       #475569;
    --shadow-sm:   0 1px 2px rgba(0,0,0,0.3);
    --shadow:      0 1px 3px rgba(0,0,0,0.4);
    --shadow-md:   0 4px 6px rgba(0,0,0,0.4);
  }
}

html { font-size: 15px; }
body {
  font-family: var(--font);
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
  -webkit-font-smoothing: antialiased;
}

/* ── Keyboard focus ring + press scale (shared) ─────────────────────────── */
button {
  outline: none;
  transition:
    border-color 0.15s ease,
    color 0.15s ease,
    background 0.15s ease,
    box-shadow 0.2s ease,
    outline 0.2s ease,
    outline-offset 0.2s ease,
    transform 0.12s ease;
}
button:focus-visible {
  outline: 2px solid var(--border-focus);
  outline-offset: 2px;
}
button:active:not(:disabled) {
  transform: scale(0.97);
}

a.btn-download,
a.link-btn {
  outline: none;
  transition:
    border-color 0.15s ease,
    color 0.15s ease,
    background 0.15s ease,
    box-shadow 0.2s ease,
    outline 0.2s ease,
    outline-offset 0.2s ease,
    transform 0.12s ease;
}
a.btn-download:focus-visible,
a.link-btn:focus-visible {
  outline: 2px solid var(--border-focus);
  outline-offset: 2px;
}
a.btn-download:active,
a.link-btn:active {
  transform: scale(0.97);
}

input[type="radio"],
input[type="checkbox"] {
  transition: transform 0.12s ease, outline-offset 0.2s ease;
}
input[type="radio"]:focus-visible,
input[type="checkbox"]:focus-visible {
  outline: 2px solid var(--border-focus);
  outline-offset: 2px;
}
input[type="radio"]:active,
input[type="checkbox"]:active {
  transform: scale(0.88);
}

/* ── Header ───────────────────────────────────────────────────────────────── */
.app-header {
  background: var(--bg2); border-bottom: 1px solid var(--border);
  position: sticky; top: 0; z-index: 100;
}
.header-inner {
  max-width: 1280px; margin: 0 auto;
  padding: 0 24px; height: 52px;
  display: flex; align-items: center; justify-content: space-between;
}
.logo { display: flex; align-items: center; gap: 9px; }
.logo-mark { width: 20px; height: 20px; object-fit: contain; }
.logo-text { font-size: 0.95rem; color: var(--text2); letter-spacing: -0.01em; }
.logo-text strong { color: var(--text); font-weight: 700; }

.header-actions { display: flex; align-items: center; gap: 6px; }
.hdr-divider { width: 1px; height: 18px; background: var(--border2); margin: 0 4px; }

.hdr-btn {
  background: var(--bg3); border: 1px solid var(--border2);
  border-radius: var(--radius); color: var(--text2);
  cursor: pointer; font-family: var(--font);
  font-size: 0.82rem; font-weight: 500;
  padding: 6px 14px;
  box-shadow: var(--shadow-sm);
}
.hdr-btn:hover:not(:disabled) { border-color: var(--accent); color: var(--accent); background: var(--accent-light); }
.hdr-btn:disabled { opacity: 0.4; cursor: not-allowed; }

/* ── Open toast ───────────────────────────────────────────────────────────── */
.open-toast {
  position: fixed; top: 62px; left: 50%; transform: translateX(-50%);
  background: var(--bg2); border: 1px solid var(--border);
  border-radius: var(--radius-lg); padding: 10px 20px;
  font-size: 0.82rem; font-weight: 500; color: var(--text2);
  box-shadow: var(--shadow-md); z-index: 500; max-width: 560px;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.open-toast.success { border-color: color-mix(in srgb, var(--green) 30%, transparent); color: var(--green); }
.open-toast.error   { border-color: color-mix(in srgb, var(--red)   30%, transparent); color: var(--red); }

.toast-enter-active, .toast-leave-active { transition: opacity 0.2s, transform 0.2s; }
.toast-enter-from, .toast-leave-to { opacity: 0; transform: translateX(-50%) translateY(-8px); }

/* ── Layout ───────────────────────────────────────────────────────────────── */
.app-main { max-width: 1280px; margin: 0 auto; padding: 24px 24px 64px; }
.layout { display: grid; grid-template-columns: 1fr 420px; gap: 20px; align-items: start; }
.layout.layout-single { grid-template-columns: 1fr; }
.layout.layout-single .sidebar { display: none; }
.sidebar { display: flex; flex-direction: column; gap: 16px; }

.card {
  background: var(--bg2); border: 1px solid var(--border);
  border-radius: var(--radius-lg); box-shadow: var(--shadow); overflow: hidden;
}

@media (max-width: 960px) {
  .layout { grid-template-columns: 1fr; }
  .app-main { padding: 16px 16px 48px; }
}

/* ── Active build banner ──────────────────────────────────────────────────── */
.active-build-banner {
  max-width: 1280px; margin: 12px auto 0; padding: 0 24px;
  display: flex; align-items: flex-start;
  justify-content: space-between; gap: 16px;
  background: color-mix(in srgb, var(--amber) 8%, var(--bg2));
  border: 1px solid color-mix(in srgb, var(--amber) 30%, transparent);
  border-radius: var(--radius-lg);
  padding: 14px 18px;
  box-shadow: var(--shadow);
}

.ab-left { display: flex; align-items: flex-start; gap: 12px; flex: 1; min-width: 0; }

.ab-dot {
  width: 9px; height: 9px; border-radius: 50%;
  background: var(--amber); flex-shrink: 0; margin-top: 5px;
  animation: pulse-amber 1.4s ease-in-out infinite;
}
@keyframes pulse-amber {
  0%,100% { box-shadow: 0 0 0 0 color-mix(in srgb, var(--amber) 40%, transparent); }
  50%     { box-shadow: 0 0 0 6px color-mix(in srgb, var(--amber) 0%, transparent); }
}

.ab-title {
  font-size: 0.85rem; font-weight: 600;
  color: var(--amber); margin-bottom: 3px;
}
.ab-sub {
  font-size: 0.76rem; color: var(--text3); line-height: 1.5;
}

.ab-actions { display: flex; gap: 8px; flex-shrink: 0; align-items: center; }

.ab-btn-resume {
  background: var(--amber); border: none;
  border-radius: var(--radius); color: #fff;
  font-family: var(--font); font-size: 0.82rem; font-weight: 600;
  padding: 7px 16px; cursor: pointer;
  box-shadow: 0 1px 2px rgba(245,158,11,0.3);
}
.ab-btn-resume:hover { background: #d97706; }

.ab-btn-dismiss {
  background: var(--bg3); border: 1px solid var(--border2);
  border-radius: var(--radius); color: var(--text2);
  font-family: var(--font); font-size: 0.82rem; font-weight: 500;
  padding: 7px 14px; cursor: pointer;
}
.ab-btn-dismiss:hover { border-color: var(--red); color: var(--red); }

/* ── Loading screen ───────────────────────────────────────────────────── */
.loading-screen {
  position: fixed; left: 0; top: 0; right: 0; bottom: 0;
  background: var(--bg); z-index: 999999;
  display: flex; align-items: center; justify-content: center;
}
.loading-content {
  display: flex; flex-direction: column; align-items: center; gap: 16px;
}
.loading-logo {
  color: var(--accent);
  animation: bounce 1s ease-in-out infinite;
}
@keyframes bounce {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-8px); }
}
.loading-spinner {
  width: 28px; height: 28px;
  border: 3px solid var(--border2);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
.loading-text {
  font-size: 0.85rem; color: var(--text3);
  font-weight: 500;
}

.fade-enter-active, .fade-leave-active { transition: opacity 0.4s ease; }
.fade-enter-from, .fade-leave-to { opacity: 0; }

</style>