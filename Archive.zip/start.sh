#!/usr/bin/env bash
# start.sh — Startup command trong Pterodactyl panel:
#   bash start.sh
# ─────────────────────────────────────────────────────
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"

# Thêm user-space bins và ffmpeg static vào PATH
export PATH="$ROOT/bin:$HOME/.local/bin:$PATH"

# Báo cho worker.py biết ffmpeg ở đâu
if [ -f "$ROOT/bin/ffmpeg" ]; then
    export _HRZN_FFMPEG_EXE="$ROOT/bin/ffmpeg"
fi

PORT="${PORT:-8000}"
echo "[start.sh] Starting uvicorn on port $PORT ..."

exec uvicorn main:app \
    --host 0.0.0.0 \
    --port "$PORT" \
    --workers 1 \
    --app-dir "$ROOT/backend"
