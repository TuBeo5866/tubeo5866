# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "C"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_C
  "/root/xmrig/src/3rdparty/libethash/ethash_internal.c" "/root/xmrig/build/src/3rdparty/libethash/CMakeFiles/ethash.dir/ethash_internal.c.o"
  "/root/xmrig/src/3rdparty/libethash/keccakf800.c" "/root/xmrig/build/src/3rdparty/libethash/CMakeFiles/ethash.dir/keccakf800.c.o"
  )
set(CMAKE_C_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_C
  "CL_TARGET_OPENCL_VERSION=200"
  "CL_USE_DEPRECATED_OPENCL_1_2_APIS"
  "HAVE_BUILTIN_CLEAR_CACHE"
  "HAVE_POSIX_MEMALIGN"
  "HAVE_ROTR"
  "HAVE_SYSLOG_H"
  "NDEBUG"
  "RAPIDJSON_SSE2"
  "RAPIDJSON_WRITE_DEFAULT_FLAGS=6"
  "UNICODE"
  "XMRIG_64_BIT"
  "XMRIG_ALGO_ARGON2"
  "XMRIG_ALGO_KAWPOW"
  "XMRIG_ALGO_RANDOMX"
  "XMRIG_FEATURE_ADL"
  "XMRIG_FEATURE_API"
  "XMRIG_FEATURE_AVX2"
  "XMRIG_FEATURE_BENCHMARK"
  "XMRIG_FEATURE_CUDA"
  "XMRIG_FEATURE_ENV"
  "XMRIG_FEATURE_HTTP"
  "XMRIG_FEATURE_HWLOC"
  "XMRIG_FEATURE_MSR"
  "XMRIG_FEATURE_NVML"
  "XMRIG_FEATURE_OPENCL"
  "XMRIG_FEATURE_SSE4_1"
  "XMRIG_FIX_RYZEN"
  "XMRIG_JSON_SINGLE_LINE_ARRAY"
  "XMRIG_MINER_PROJECT"
  "XMRIG_OS_LINUX"
  "XMRIG_OS_UNIX"
  "XMRIG_STRICT_OPENCL_CACHE"
  "XMRIG_VAES"
  "_FILE_OFFSET_BITS=64"
  "_GNU_SOURCE"
  "__STDC_FORMAT_MACROS"
  )

# The include file search paths:
set(CMAKE_C_TARGET_INCLUDE_PATH
  "../src/3rdparty/libethash/../.."
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
