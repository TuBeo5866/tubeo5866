# mcpack-studio — Pterodactyl Deploy Guide

## Cấu trúc

```
/home/container/
├── install.sh          ← chạy 1 lần qua Console tab
├── start.sh            ← Startup command trỏ vào đây
├── bin/
│   └── ffmpeg          ← tự download bởi install.sh
├── frontend/
└── backend/
    ├── main.py
    ├── worker.py
    ├── task_manager.py
    ├── schemas.py
    ├── requirements.txt
    └── static/         ← Vue build output (sinh ra sau install.sh)
```

---

## Lần đầu deploy

**Bước 1** — Upload repo vào container qua SFTP / File Manager

**Bước 2** — Tab **Console**, chạy 1 lần:
```bash
bash install.sh
```

**Bước 3** — Tab **Startup**, set:
```
Startup Command:  bash start.sh
PORT:             <port đã mở>
```

**Bước 4** — Bấm **Start** → truy cập `http://IP:PORT`

---

## Khi update code

```bash
# Sửa backend Python → restart từ panel là đủ

# Sửa frontend Vue → chạy lại trong Console:
cd frontend && npm run build
# rồi restart từ panel
```

---

## Lưu ý

- `install.sh` chỉ cần chạy **1 lần** — hoặc khi update deps lớn
- `start.sh` là startup command, chạy mỗi lần server start — rất nhanh
- ffmpeg static binary không cần sudo, nằm trong `bin/`
- yt-dlp cài vào `~/.local/bin`, `start.sh` tự patch PATH
