#!/usr/bin/env bash
# install.sh — chạy 1 lần qua tab Console của Pterodactyl
# Không cần sudo. Tất cả cài vào user-space hoặc ./bin/
#
# Cách dùng:
#   bash install.sh
# ─────────────────────────────────────────────────────────────────────────────
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
BIN="$ROOT/bin"
mkdir -p "$BIN"

echo ""
echo "═══════════════════════════════════════════════"
echo "  mcpack-studio — install.sh"
echo "═══════════════════════════════════════════════"

# ── 1. Python deps ────────────────────────────────────────────────────────────
echo ""
echo "[1/4] Installing Python packages (--user) ..."
pip install --user --quiet -r "$ROOT/backend/requirements.txt"
pip install --user --quiet yt-dlp
echo "      Python packages OK ✓"

# ── 2. ffmpeg static binary ───────────────────────────────────────────────────
echo ""
echo "[2/4] Downloading ffmpeg static binary ..."

ARCH="$(uname -m)"
if [ "$ARCH" = "aarch64" ] || [ "$ARCH" = "arm64" ]; then
    FF_URL="https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-arm64-static.tar.xz"
else
    FF_URL="https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-amd64-static.tar.xz"
fi

TMP="$(mktemp -d)"
curl -# -L "$FF_URL" -o "$TMP/ffmpeg.tar.xz"
tar -xf "$TMP/ffmpeg.tar.xz" -C "$TMP"

# Tìm binary ffmpeg trong thư mục giải nén
FF_BIN="$(find "$TMP" -name "ffmpeg" -type f | head -1)"
if [ -z "$FF_BIN" ]; then
    echo "ERROR: ffmpeg binary not found after extract!"
    exit 1
fi

cp "$FF_BIN" "$BIN/ffmpeg"
chmod +x "$BIN/ffmpeg"
rm -rf "$TMP"

echo "      ffmpeg OK ✓  ($("$BIN/ffmpeg" -version 2>&1 | head -1))"

# ── 3. Node deps + build Vue ──────────────────────────────────────────────────
echo ""
echo "[3/4] Building Vue frontend ..."
cd "$ROOT/frontend"
npm ci --silent
npm run build          # output → ../backend/static/
echo "      Vue build OK ✓"

# ── 4. Kiểm tra cuối ─────────────────────────────────────────────────────────
echo ""
echo "[4/4] Sanity checks ..."

python3 -c "import fastapi, uvicorn, PIL, requests; print('      Python imports OK ✓')"

if [ -f "$ROOT/backend/static/index.html" ]; then
    echo "      frontend/static OK ✓"
else
    echo "      WARNING: backend/static/index.html not found!"
fi

echo ""
echo "═══════════════════════════════════════════════"
echo "  Setup complete!"
echo ""
echo "  Bước tiếp theo:"
echo "  1. Vào Pterodactyl panel → Startup"
echo "  2. Set  PY_FILE = start.py"
echo "  3. Set  PORT    = <port bạn muốn>"
echo "  4. Bấm Start server"
echo "═══════════════════════════════════════════════"
