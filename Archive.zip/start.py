"""
start.py  —  Pterodactyl entry point
=====================================================
Pterodactyl egg Python fix startup command thành:
    python {{PY_FILE}}
→ set PY_FILE = start.py trong panel.

File này làm 2 việc:
  1. Thêm ~/.local/bin vào PATH (pip --user installs)
  2. Khởi động uvicorn serve backend/ (đã có Vue static bên trong)
"""

import os
import sys
import subprocess
from pathlib import Path

ROOT    = Path(__file__).parent.resolve()
BACKEND = ROOT / "backend"
BIN_DIR = ROOT / "bin"          # ffmpeg static binary nằm ở đây

# ── Patch PATH ────────────────────────────────────────────────────────────────
# pip install --user để packages vào ~/.local/bin
local_bin = Path.home() / ".local" / "bin"
extra     = f"{local_bin}{os.pathsep}{BIN_DIR}"
os.environ["PATH"] = extra + os.pathsep + os.environ.get("PATH", "")

# Báo cho worker.py biết ffmpeg nằm ở đâu (fallback nếu không có trong PATH)
ffmpeg_bin = BIN_DIR / "ffmpeg"
if ffmpeg_bin.exists():
    os.environ["_HRZN_FFMPEG_EXE"] = str(ffmpeg_bin)

# ── Chạy uvicorn ──────────────────────────────────────────────────────────────
port = os.environ.get("PORT", "8000")   # Pterodactyl inject biến PORT tự động

print(f"[start.py] Launching uvicorn on port {port} ...")
print(f"[start.py] Backend: {BACKEND}")
print(f"[start.py] ffmpeg:  {os.environ.get('_HRZN_FFMPEG_EXE', 'from PATH')}")

result = subprocess.run(
    [
        sys.executable, "-m", "uvicorn",
        "main:app",
        "--host", "0.0.0.0",
        "--port", port,
        "--workers", "1",
    ],
    cwd=str(BACKEND),
)

sys.exit(result.returncode)
