import subprocess
import os

def run_commands():
    command = "cd frontend && npm run build && cd .. && python start.py"
    subprocess.run(command, shell=True, check=True)
if __name__ == "__main__":
    run_commands()