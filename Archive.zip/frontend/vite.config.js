import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      }
    }
  },
  build: {
    // khi build local (npm run build từ frontend/):
    // output ra ../backend/static để FastAPI serve
    outDir: '../backend/static',
    emptyOutDir: true,
  }
})
