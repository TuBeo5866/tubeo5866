import { ref } from 'vue'

const BANNER_URL = '/api/banner'

// Singleton state — tồn tại suốt vòng đời app
export const bannerUrl     = ref(null)
export const bannerLoading = ref(true)
export const bannerError   = ref(false)

export function prefetchBanner() {
  const img = new Image()
  img.onload = () => {
    bannerUrl.value     = BANNER_URL
    bannerLoading.value = false
  }
  img.onerror = () => {
    bannerError.value   = true
    bannerLoading.value = false
  }
  img.src = BANNER_URL
}
