<template>
  <Transition name="modal">
    <Teleport to="body">
      <div class="modal-overlay" @click.self="$emit('close')">
        <div class="modal">

          <div class="modal-header">
            <span>About</span>
            <button class="btn-close" @click="$emit('close')">✕</button>
          </div>

          <div class="modal-body">

            <div v-if="!bannerError" class="banner-img-wrap">
              <div v-if="bannerLoading" class="banner-skeleton"></div>
              <img v-else-if="bannerUrl" :src="bannerUrl" alt="About banner" class="banner-img" />
            </div>

            <div class="about-title">
              <h2>Extension Studio</h2>
              <p>HorizonUI / NekoUI · by TuBeo5866</p>
            </div>

            <div class="info-block">
              <p>A web-based tool for building HorizonUI and NekoUI resource pack extensions for Minecraft Bedrock and Java editions.</p>
              <p class="credit">Original UI by <strong>Han's404</strong> · YouTube: <a href="https://youtube.com/@zxyn404" target="_blank">@zxyn404</a></p>
            </div>

            <div class="links">
              <a href="https://tubeo5866.com" target="_blank" class="link-btn">Website</a>
              <a href="https://github.com/usira-or-arisu/horizonui-and-nekoui-extension-studio" target="_blank" class="link-btn">GitHub</a>
              <a href="https://discord.gg/3fe3ySCJZf" target="_blank" class="link-btn">Discord</a>
              <a href="mailto:support@tubeo5866.com" class="link-btn">Email</a>
              <a href="https://forms.gle/KTJQCq8EdseQhFKp9" target="_blank" class="link-btn">Request Feature</a>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn-ok" @click="$emit('close')">OK</button>
          </div>

        </div>
      </div>
    </Teleport>
  </Transition>
</template>

<script setup>
import { bannerUrl, bannerLoading, bannerError } from '../composables/useBanner.js'

defineEmits(['close'])
</script>

<style scoped>
.modal-overlay {
  position: fixed; inset: 0;
  background: rgba(15,23,42,0.5); backdrop-filter: blur(4px);
  display: flex; align-items: center; justify-content: center; z-index: 1000;
}

.modal-enter-active,
.modal-leave-active {
  transition: all 0.25s ease;
}
.modal-enter-active .modal {
  transition: transform 0.25s ease, opacity 0.25s ease;
}
.modal-leave-active .modal {
  transition: transform 0.15s ease, opacity 0.15s ease;
}
.modal-enter-from,
.modal-leave-to {
  opacity: 0;
}
.modal-enter-from .modal {
  transform: scale(0.95) translateY(10px);
  opacity: 0;
}
.modal-leave-to .modal {
  transform: scale(0.95);
  opacity: 0;
}
.modal {
  background: var(--bg2); border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  box-shadow: 0 20px 40px rgba(0,0,0,0.15);
  width: 460px; max-width: 94vw;
  display: flex; flex-direction: column;
}
.modal-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 18px; border-bottom: 1px solid var(--border);
  font-size: 0.88rem; font-weight: 600; background: var(--bg3);
  border-radius: var(--radius-lg) var(--radius-lg) 0 0;
}
.btn-close {
  background: none; border: none; color: var(--text3);
  cursor: pointer; font-size: 0.78rem; padding: 3px 7px; border-radius: 6px;
  transition: color 0.15s ease, background 0.15s ease, outline 0.2s ease, outline-offset 0.2s ease, transform 0.12s ease;
}
.btn-close:hover { color: var(--red); background: color-mix(in srgb, var(--red) 8%, transparent); }

.modal-body { padding: 0 0 16px; display: flex; flex-direction: column; gap: 20px; }

.info-block { display: flex; flex-direction: column; gap: 8px; }
.info-block p { font-size: 0.83rem; color: var(--text2); line-height: 1.6; }
.credit { font-size: 0.8rem !important; color: var(--text3) !important; }
.credit strong { color: var(--text2); }
.credit a { color: var(--accent); text-decoration: none; }
.credit a:hover { text-decoration: underline; }

.links { display: flex; flex-wrap: wrap; gap: 8px; }
.link-btn {
  background: var(--bg3); border: 1px solid var(--border2);
  border-radius: var(--radius); color: var(--text2);
  font-family: var(--font); font-size: 0.78rem; font-weight: 500;
  padding: 6px 14px; text-decoration: none;
  box-shadow: var(--shadow-sm);
}
.link-btn:hover { border-color: var(--accent); color: var(--accent); background: var(--accent-light); }

.modal-footer {
  display: flex; justify-content: flex-end;
  padding: 12px 18px; border-top: 1px solid var(--border);
  background: var(--bg3);
  border-radius: 0 0 var(--radius-lg) var(--radius-lg);
}
.btn-ok {
  background: var(--accent); border: none; border-radius: var(--radius);
  color: #fff; font-family: var(--font); font-size: 0.82rem; font-weight: 500;
  padding: 7px 24px; cursor: pointer;
  box-shadow: 0 1px 2px rgba(99,102,241,0.3);
  transition: background 0.15s;
}
.btn-ok:hover { background: var(--accent-hover); }

/* ── Banner image ─────────────────────────────────────────────── */
.banner-img-wrap {
  width: 100%; height: 200px;
  overflow: hidden; flex-shrink: 0;
  background: #d7d7d7;
}
@media (prefers-color-scheme: dark) {
  .banner-img-wrap { background: #334155; }
}
.banner-img {
  width: 100%; height: 100%;
  object-fit: cover; display: block;
}
.banner-skeleton {
  width: 100%; height: 100%;
  background: #d7d7d7;
  position: relative; overflow: hidden;
}
.banner-skeleton::after {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.35) 50%, transparent 100%);
  animation: banner-shimmer 1.5s linear infinite;
}
@keyframes banner-shimmer {
  from { transform: translateX(-100%); }
  to   { transform: translateX(100%); }
}
@media (prefers-color-scheme: dark) {
  .banner-skeleton { background: #334155; }
}

/* ── About title (thay thế .banner-text cũ) ───────────────────── */
.about-title { padding: 0 24px; }
.about-title h2 { font-size: 1.05rem; font-weight: 700; color: var(--text); margin-bottom: 3px; }
.about-title p  { font-size: 0.8rem; color: var(--text2); }

/* ── Padding cho các section bên dưới ─────────────────────────── */
.info-block { padding: 0 24px; display: flex; flex-direction: column; gap: 8px; }
.links      { padding: 0 24px; display: flex; flex-wrap: wrap; gap: 8px; }

</style>
