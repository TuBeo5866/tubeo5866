<template>
  <div class="build-form">

    <!-- ── Edition tabs ─────────────────────────────────────────────────── -->
    <div class="tab-bar">
      <div class="tab-group">
        <button class="tab" :class="{ active: form.edition === 'bedrock' }" @click="!disabled && (form.edition = 'bedrock')" :disabled="disabled">Bedrock Edition</button>
        <button class="tab" :class="{ active: form.edition === 'java'    }" @click="!disabled && (form.edition = 'java')"    :disabled="disabled">Java Edition</button>
      </div>
      <div class="tab-group" v-if="form.edition === 'bedrock'">
        <button class="tab" :class="{ active: form.packType === 'horizon' }" @click="!disabled && (form.packType = 'horizon')" :disabled="disabled">HorizonUI</button>
        <button class="tab" :class="{ active: form.packType === 'neko'    }" @click="!disabled && (form.packType = 'neko')"    :disabled="disabled">NekoUI</button>
      </div>
    </div>

    <form @submit.prevent="handleSubmit" class="form-body">

      <!-- ── OUTPUT ──────────────────────────────────────────────────────── -->
      <div class="form-section">
        <div class="section-title">Output</div>

        <div class="field-row">
          <label>Extension Name</label>
          <div class="input-group">
            <input v-model="form.packName" type="text" placeholder="MyExtension" :disabled="disabled" required />
            <button type="button" class="btn-side" @click="openFormatDialog('packName')" :disabled="disabled">Format...</button>
          </div>
        </div>

        <div class="field-row">
          <label>Creator Name</label>
          <div class="input-group">
            <input v-model="form.creatorName" type="text" placeholder="Unknown" :disabled="disabled" />
            <button type="button" class="btn-side" @click="openFormatDialog('creatorName')" :disabled="disabled">Format...</button>
          </div>
        </div>

        <div class="field-row">
          <label>Pack Icon</label>
          <div class="input-group icon-field-group">
            <img v-if="iconPreview" class="icon-thumb" :src="iconPreview" alt="icon" />
            <input
              class="input-readonly"
              :class="{ 'has-icon': iconPreview }"
              :value="form.iconFile ? form.iconFile.name : ''"
              placeholder="(optional) Select a PNG file"
              readonly
              @click="!disabled && $refs.iconInput.click()"
            />
            <input ref="iconInput" type="file" accept="image/*" style="display:none" @change="onIconChange" :disabled="disabled" />
            <button type="button" class="btn-side" @click="$refs.iconInput.click()" :disabled="disabled">Browse...</button>
            <button v-if="form.iconFile" type="button" class="btn-icon-clear" @click="clearIcon" :disabled="disabled">✕</button>
          </div>
        </div>

        <div class="field-row">
          <label>Background Type</label>
          <div class="radio-group">
            <label class="radio-opt" v-for="opt in bgTypeOptions" :key="opt.value">
              <input type="radio" v-model="form.bgType" :value="opt.value" :disabled="disabled" />
              <span>{{ opt.label }}</span>
            </label>
          </div>
        </div>

        <div class="field-row">
          <label>Extension Version</label>
          <div class="version-group">
            <input v-model.number="form.verX" type="number" min="0" class="ver-input" :disabled="disabled" />
            <span class="ver-sep">.</span>
            <input v-model.number="form.verY" type="number" min="0" class="ver-input" :disabled="disabled" />
            <span class="ver-sep">.</span>
            <input v-model.number="form.verZ" type="number" min="0" class="ver-input" :disabled="disabled" />
          </div>
        </div>
      </div>

      <!-- ── SOURCES ─────────────────────────────────────────────────────── -->
      <div class="form-section">
        <div class="section-title">Sources</div>

        <div class="field-row">
          <label>Source Type</label>
          <div class="radio-group">
            <label class="radio-opt" v-for="opt in sourceTypeOptions" :key="opt.value">
              <input type="radio" v-model="form.sourceType" :value="opt.value" :disabled="disabled" />
              <span>{{ opt.label }}</span>
            </label>
          </div>
        </div>

        <div v-if="form.sourceType === 'video'" class="field-row">
          <label>Video File</label>
          <div class="input-group">
            <input class="input-readonly" :value="form.videoFile ? form.videoFile.name : ''" placeholder="Local video file path" readonly @click="!disabled && $refs.videoInput.click()" />
            <input ref="videoInput" type="file" accept="video/*" style="display:none" @change="onVideoChange" :disabled="disabled" />
            <button type="button" class="btn-side" @click="$refs.videoInput.click()" :disabled="disabled">Browse...</button>
          </div>
        </div>

        <div v-if="form.sourceType === 'youtube'" class="field-row">
          <label>YouTube URL</label>
          <input v-model="form.youtubeUrl" type="url" placeholder="https://www.youtube.com/watch?v=..." :disabled="disabled" />
        </div>

        <div v-if="form.sourceType === 'image'" class="field-row">
          <label>Image File</label>
          <div class="input-group">
            <input class="input-readonly" :value="form.imageFile ? form.imageFile.name : ''" placeholder="Local image file path" readonly @click="!disabled && $refs.imageInput.click()" />
            <input ref="imageInput" type="file" accept="image/*" style="display:none" @change="onImageChange" :disabled="disabled" />
            <button type="button" class="btn-side" @click="$refs.imageInput.click()" :disabled="disabled">Browse...</button>
          </div>
        </div>

        <template v-if="form.sourceType !== 'image'">
          <div class="field-row">
            <label>Start Time <span class="hint">(s or mm:ss)</span></label>
            <input v-model="form.startTime" type="text" placeholder="0" class="input-short mono" :disabled="disabled" />
          </div>
          <div class="field-row">
            <label>End Time <span class="hint">(s or mm:ss)</span></label>
            <input v-model="form.endTime" type="text" placeholder="30" class="input-short mono" :disabled="disabled" />
          </div>
          <div class="field-row">
            <label>Extract FPS</label>
            <input v-model.number="form.fps" type="number" min="1" max="60" class="input-short" :disabled="disabled" />
          </div>
          <div class="field-row">
            <label>Anim Frames</label>
            <span class="computed-value">{{ animFramesComputed }}</span>
          </div>
        </template>
      </div>

      <!-- ── ASSETS (Bedrock only) ──────────────────────────────────────── -->
      <div class="form-section" v-if="form.edition === 'bedrock'">
        <div class="section-title">Assets</div>

        <div class="field-row">
          <label>Custom Container Background</label>
          <div class="input-group">
            <span class="input-info">{{ form.containerBgFiles.length || 0 }} custom</span>
            <button type="button" class="btn-side" @click="showContainerBgDialog = true" :disabled="disabled">Edit</button>
          </div>
        </div>

        <div class="field-row">
          <label>Background Music File</label>
          <div class="input-group">
            <input class="input-readonly" :value="form.bgmFile ? form.bgmFile.name : ''" placeholder="(optional — leave blank to extract from video)" readonly @click="!disabled && $refs.bgmInput.click()" />
            <input ref="bgmInput" type="file" accept="audio/*" style="display:none" @change="onBgmChange" :disabled="disabled" />
            <button type="button" class="btn-side" @click="$refs.bgmInput.click()" :disabled="disabled">Browse...</button>
          </div>
        </div>

        <div v-if="!form.bgmFile && form.sourceType === 'youtube'" class="field-row">
          <label>BGM YouTube URL <span class="hint">(leave blank to use video URL)</span></label>
          <input v-model="form.bgmYoutubeUrl" type="url" placeholder="https://www.youtube.com/watch?v=..." :disabled="disabled" />
        </div>

        <div class="field-row">
          <label>Loading Background</label>
          <div class="input-group">
            <input
              class="input-readonly"
              :value="loadingBgLabel"
              placeholder="— leave blank to use a black frame"
              readonly
              @click="!disabled && openLoadingBgDialog()"
            />
            <button type="button" class="btn-side" @click="openLoadingBgDialog()" :disabled="disabled">Browse...</button>

          </div>
        </div>

        <!-- Thumbnail strip (read-only preview after dialog confirm) -->
        <div v-if="form.loadingBgFiles.length" class="loading-strip">
          <div
            v-for="(f, i) in form.loadingBgFiles"
            :key="i"
            class="strip-thumb"
            :title="f.name"
          >
            <img :src="getObjectURL(f)" :alt="f.name" />
            <span class="strip-num">{{ i + 1 }}</span>
          </div>
          <button type="button" class="strip-edit" @click="openLoadingBgDialog()" :disabled="disabled">
            Edit order
          </button>
        </div>
      </div>

      <!-- ── COMPRESSION ─────────────────────────────────────────────────── -->
      <div class="form-section">
        <div class="section-title">Compression</div>

        <div class="field-row">
          <label>Method</label>
          <select v-model="form.compressMethod" :disabled="disabled">
            <option value="none">None</option>
            <option value="lossless">Lossless</option>
            <option value="pillow">Pillow</option>
            <option value="ffmpeg">FFmpeg</option>
            <option value="tinypng">TinyPNG</option>
            <option value="imagecompressr">ImageCompressR</option>
            <option value="kraken">Kraken.io</option>
            <option value="imagekit">ImageKit</option>
            <option value="cloudinary">Cloudinary</option>
            <option value="compressor">Compressor.io</option>
          </select>
        </div>

        <!-- TinyPNG -->
        <div v-if="form.compressMethod === 'tinypng'" class="field-row">
          <label>API Key</label>
          <input v-model="form.compressKeys.tinify_key" type="text" placeholder="TinyPNG API key" :disabled="disabled" class="mono" />
        </div>
        <!-- Kraken.io -->
        <template v-if="form.compressMethod === 'kraken'">
          <div class="field-row">
            <label>API Key</label>
            <input v-model="form.compressKeys.kraken_key" type="text" placeholder="Kraken API key" :disabled="disabled" class="mono" />
          </div>
          <div class="field-row">
            <label>API Secret</label>
            <input v-model="form.compressKeys.kraken_secret" type="text" placeholder="Kraken API secret" :disabled="disabled" class="mono" />
          </div>
          <div class="field-row">
            <label>Quality <span class="hint">1–100</span></label>
            <input v-model.number="form.compressKeys.kraken_quality" type="number" min="1" max="100" class="input-short" :disabled="disabled" />
          </div>
        </template>
        <!-- ImageKit -->
        <template v-if="form.compressMethod === 'imagekit'">
          <div class="field-row">
            <label>Public Key</label>
            <input v-model="form.compressKeys.imagekit_key" type="text" placeholder="ImageKit public key" :disabled="disabled" class="mono" />
          </div>
          <div class="field-row">
            <label>Private Key</label>
            <input v-model="form.compressKeys.imagekit_secret" type="text" placeholder="ImageKit private key" :disabled="disabled" class="mono" />
          </div>
          <div class="field-row">
            <label>URL Endpoint</label>
            <input v-model="form.compressKeys.imagekit_urlendpoint" type="text" placeholder="https://ik.imagekit.io/your_id" :disabled="disabled" />
          </div>
          <div class="field-row">
            <label>Quality <span class="hint">1–100</span></label>
            <input v-model.number="form.compressKeys.imagekit_quality" type="number" min="1" max="100" class="input-short" :disabled="disabled" />
          </div>
        </template>
        <!-- Cloudinary -->
        <template v-if="form.compressMethod === 'cloudinary'">
          <div class="field-row">
            <label>Cloud Name</label>
            <input v-model="form.compressKeys.cloudinary_name" type="text" placeholder="your-cloud-name" :disabled="disabled" class="mono" />
          </div>
          <div class="field-row">
            <label>API Key</label>
            <input v-model="form.compressKeys.cloudinary_key" type="text" placeholder="Cloudinary API key" :disabled="disabled" class="mono" />
          </div>
          <div class="field-row">
            <label>API Secret</label>
            <input v-model="form.compressKeys.cloudinary_secret" type="text" placeholder="Cloudinary API secret" :disabled="disabled" class="mono" />
          </div>
        </template>
        <!-- ImageCompressR note -->
        <div v-if="form.compressMethod === 'imagecompressr'" class="field-row">
          <label></label>
          <p class="field-note">Uses Selenium + Chrome — requires Chrome installed on server.</p>
        </div>
        <!-- Pillow quality -->
        <div v-if="form.compressMethod === 'pillow' || form.compressMethod === 'compressor'" class="field-row">
          <label>Quality</label>
          <select v-model="form.compressKeys.pillow_quality" :disabled="disabled">
            <option value="maximum">Maximum (95)</option>
            <option value="high">High (85)</option>
            <option value="medium">Medium (70)</option>
            <option value="low">Low (50)</option>
          </select>
        </div>
        <!-- FFmpeg quality -->
        <div v-if="form.compressMethod === 'ffmpeg'" class="field-row">
          <label>Quality <span class="hint">qv 1–31, lower=better</span></label>
          <input v-model.number="form.compressKeys.ffmpeg_qv" type="number" min="1" max="31" class="input-short" :disabled="disabled" />
        </div>
      </div>

      <!-- ── OUTPUT OPTIONS ──────────────────────────────────────────────── -->
      <div class="form-section">
        <div class="section-title">Output Options</div>

        <div class="field-row">
          <label>Output Filename</label>
          <input v-model="form.outputName" type="text" :placeholder="form.packName || 'MyExtension'" :disabled="disabled" />
        </div>

      </div>

      <!-- ── SUBMIT ──────────────────────────────────────────────────────── -->
      <div class="form-footer">
        <button type="submit" class="btn-build" :disabled="disabled || submitting || !isValid">
          <span v-if="!disabled && !submitting">
            <template v-if="form.edition === 'bedrock'">
              Build mcpack
              <span class="btn-sub">(Bedrock / {{ form.packType === 'neko' ? 'NekoUI' : 'HorizonUI' }})</span>
            </template>
            <template v-else>
              Build zip
              <span class="btn-sub">(Java / both UI)</span>
            </template>
          </span>
          <span v-else class="btn-building">
            <span class="spinner"></span> Building…
          </span>
        </button>
        <p v-if="!isValid && !disabled" class="validation-hint">Extension name is required</p>
      </div>

    </form>
  <!-- Debug toast -->
  <Transition name="debug-toast">
    <div v-if="debugToast" class="debug-toast">{{ debugToast }}</div>
  </Transition>

  <!-- Format dialog -->
  <FormatDialog
    v-if="formatDialog.show"
    :model-value="form[formatDialog.field] ?? ''"
    @update:model-value="onFormatConfirm"
    @close="formatDialog.show = false"
  />

  <!-- Loading background dialog -->
  <LoadingBgDialog
    v-if="showLoadingBgDialog"
    v-model="form.loadingBgFiles"
    @close="onLoadingBgDialogClose"
  />

  <!-- Container background dialog -->
  <ContainerBgDialog
    v-if="showContainerBgDialog"
    v-model="form.containerBgFiles"
    @close="showContainerBgDialog = false"
  />

  </div>
</template>

<script setup>
import { ref, computed, onBeforeUnmount, watch } from 'vue'
import FormatDialog from './FormatDialog.vue'
import ContainerBgDialog from './ContainerBgDialog.vue'
import LoadingBgDialog from './LoadingBgDialog.vue'

const props = defineProps({ disabled: Boolean, debug: { type: Boolean, default: false } })
const emit  = defineEmits(['submitted'])

const form = ref({
  edition:     'bedrock',
  packType:    'horizon',
  packName:    '',
  creatorName: 'Unknown',
  iconFile:    null,
  bgType:      'dynamic',
  verX: 1, verY: 0, verZ: 0,
  sourceType:  'video',
  videoFile:   null,
  youtubeUrl:  '',
  imageFile:   null,
  startTime:   '0',
  endTime:     '30',
  fps:         20,
  containerBgFiles: [],
  bgmFile:          null,
  bgmYoutubeUrl:    '',
  loadingBgFiles:   [],
  compressMethod:   'none',
  compressKeys: {
    tinify_key:           '',
    kraken_key:           '', kraken_secret:   '', kraken_quality:   90,
    imagekit_key:         '', imagekit_secret: '', imagekit_urlendpoint: '', imagekit_quality: 90,
    cloudinary_name:      '', cloudinary_key:  '', cloudinary_secret: '',
    pillow_quality:       'high',
    ffmpeg_qv:            2,
  },
  outputName:       '',
  outputFormat:     'mcpack',
})

const iconPreview = ref(null)
const submitting = ref(false)

// Dialog state
const formatDialog = ref({ show: false, field: null })
const showContainerBgDialog = ref(false)
const showLoadingBgDialog   = ref(false)

const bgTypeOptions = computed(() => [
  { value:'dynamic', label:'Dynamic' },
  { value:'static',  label:'Static'  },
  ...(form.value.edition !== 'java' ? [{ value:'both', label:'Both' }] : []),
])
const sourceTypeOptions = [{ value:'video',label:'Video'},{ value:'youtube',label:'YouTube Video'},{ value:'image',label:'Image'}]

watch(() => form.value.edition, (val) => {
  if (val === 'java' && form.value.bgType === 'both') {
    form.value.bgType = 'dynamic'
  }
})

const isValid = computed(() => form.value.packName.trim().length > 0)

const animFramesComputed = computed(() => {
  const s = parseTime(form.value.startTime)
  const e = parseTime(form.value.endTime)
  if (s === null || e === null || e <= s) return '—'
  return Math.floor((e - s) * form.value.fps)
})


const loadingBgLabel = computed(() => {
  const n = form.value.loadingBgFiles.length
  return n ? `${n} image${n > 1 ? 's' : ''} selected` : ''
})

function parseTime(v) {
  if (v === null || v === undefined || v === '') return null
  const parts = String(v).trim().split(':').map(Number)
  if (parts.some(isNaN)) return null
  if (parts.length === 1) return parts[0]
  if (parts.length === 2) return parts[0]*60+parts[1]
  if (parts.length === 3) return parts[0]*3600+parts[1]*60+parts[2]
  return null
}

function openFormatDialog(field) {
  formatDialog.value = { show: true, field }
}
function onFormatConfirm(val) {
  if (formatDialog.value.field) form.value[formatDialog.value.field] = val
  formatDialog.value.show = false
}

function onIconChange(e) {
  const f = e.target.files[0]; if (!f) return
  form.value.iconFile = f
  if (iconPreview.value) URL.revokeObjectURL(iconPreview.value)
  iconPreview.value = URL.createObjectURL(f)
  e.target.value = ''
}
function clearIcon() {
  form.value.iconFile = null
  if (iconPreview.value) { URL.revokeObjectURL(iconPreview.value); iconPreview.value = null }
}
function onVideoChange(e)      { form.value.videoFile   = e.target.files[0]||null; e.target.value='' }
function onImageChange(e)      { form.value.imageFile   = e.target.files[0]||null; e.target.value='' }
function onBgmChange(e)        { form.value.bgmFile     = e.target.files[0]||null; e.target.value='' }
function onContainerBgChange(e){ form.value.containerBgFiles = Array.from(e.target.files); e.target.value='' }
function clearLoadingBg()      { form.value.loadingBgFiles = [] }

// Open loading BG dialog — guard chống re-open ngay sau khi close
let _loadingBgCooldown = false
function openLoadingBgDialog() {
  if (props.disabled || _loadingBgCooldown) return
  showLoadingBgDialog.value = true
}

function onLoadingBgDialogClose() {
  showLoadingBgDialog.value = false
  _loadingBgCooldown = true
  setTimeout(() => { _loadingBgCooldown = false }, 300)
}

// Cache object URLs
const _urlCache = new WeakMap()
function getObjectURL(file) {
  if (!_urlCache.has(file)) _urlCache.set(file, URL.createObjectURL(file))
  return _urlCache.get(file)
}

onBeforeUnmount(() => { if (iconPreview.value) URL.revokeObjectURL(iconPreview.value) })

// ── Exposed: pre-fill form from Open... pack data ─────────────────────────
function prefillFromPack(data) {
  if (data.name)    form.value.packName    = data.name
  if (data.creator) form.value.creatorName = data.creator
  if (data.ver_x !== undefined) form.value.verX = data.ver_x
  if (data.ver_y !== undefined) form.value.verY = data.ver_y
  if (data.ver_z !== undefined) form.value.verZ = data.ver_z
  if (data.edition)   form.value.edition   = data.edition
  if (data.pack_type) form.value.packType  = data.pack_type
}

defineExpose({ prefillFromPack })

// ── Debug toast ───────────────────────────────────────────────────────────
const debugToast = ref('')
let _toastTimer = null

function showDebugToast(msg) {
  if (!props.debug) return
  debugToast.value = msg
  clearTimeout(_toastTimer)
  _toastTimer = setTimeout(() => { debugToast.value = '' }, 3000)
}

watch(() => form.value.edition,       (v, o) => { if (o !== undefined) showDebugToast(`Edition: ${o} → ${v}`) })
watch(() => form.value.packType,      (v, o) => { if (o !== undefined) showDebugToast(`UI type: ${o} → ${v}`) })
watch(() => form.value.sourceType,    (v, o) => { if (o !== undefined) showDebugToast(`Source type: ${o} → ${v}`) })
watch(() => form.value.bgType,        (v, o) => { if (o !== undefined) showDebugToast(`Background type: ${o} → ${v}`) })
watch(() => form.value.compressMethod,(v, o) => { if (o !== undefined) showDebugToast(`Compression: ${o} → ${v}`) })
watch(() => form.value.fps,           (v, o) => { if (o !== undefined) showDebugToast(`FPS: ${o} → ${v} (frames ≈ ${animFramesComputed.value})`) })
watch(() => form.value.videoFile,     (v)    => { if (v) showDebugToast(`Video: ${v.name} (${(v.size/1024/1024).toFixed(1)} MB)`) })
watch(() => form.value.imageFile,     (v)    => { if (v) showDebugToast(`Image: ${v.name} (${(v.size/1024).toFixed(0)} KB)`) })
watch(() => form.value.bgmFile,       (v)    => { showDebugToast(v ? `BGM: ${v.name}` : 'BGM cleared') })
watch(() => form.value.iconFile,      (v)    => { showDebugToast(v ? `Icon: ${v.name}` : 'Icon cleared') })
watch(() => form.value.loadingBgFiles,(v)    => { if (v.length) showDebugToast(`Loading BG: ${v.length} image(s)`) }, { deep: true })

// Parent disables the form while building. Once it is enabled again, restore
// the normal "Build ..." button state.
watch(
  () => props.disabled,
  (isDisabled) => {
    if (!isDisabled) submitting.value = false
  }
)


async function handleSubmit() {
  if (!isValid.value || props.disabled || submitting.value) return
  submitting.value = true
  formatDialog.value.show = false
  showContainerBgDialog.value = false
  showLoadingBgDialog.value = false
  const fd = new FormData()

  const sourceFile = form.value.sourceType === 'video'   ? form.value.videoFile
                   : form.value.sourceType === 'image'   ? form.value.imageFile
                   : null

  const meta = {
    pack_name:        form.value.packName,
    creator:          form.value.creatorName,
    uuid: '', uuid2: '',
    version:          `${form.value.verX}.${form.value.verY}.${form.value.verZ}`,
    min_engine:       '1.20.0',
    edition:          form.value.edition,
    pack_type:        form.value.packType,
    bg_type:          form.value.bgType,
    source_type:      form.value.sourceType,
    youtube_url:      form.value.youtubeUrl,
    start_time:       form.value.startTime,
    end_time:         form.value.endTime,
    fps:              form.value.fps,
    max_frames:       typeof animFramesComputed.value === 'number' ? animFramesComputed.value : 9999,
    enable_anim_bg:   true,
    anim_source:      form.value.sourceType === 'youtube' ? 'youtube' : 'file',
    enable_loading_bg: form.value.loadingBgFiles.length > 0,
    enable_bgm:       true,
    bgm_source:       form.value.bgmFile ? 'file' : (form.value.bgmYoutubeUrl ? 'youtube' : 'video'),
    bgm_youtube_url:  form.value.bgmYoutubeUrl,
    enable_icon:      !!form.value.iconFile,
    compress_method:  form.value.compressMethod,
    ...form.value.compressKeys,
    output_name:      form.value.outputName || form.value.packName.replace(/\s+/g,'_'),
    output_format:    form.value.edition === 'java' ? 'zip' : form.value.outputFormat,
  }
  fd.append('meta', JSON.stringify(meta))

  if (sourceFile)               fd.append('anim_files', sourceFile)
  if (form.value.bgmFile)       fd.append('bgm_file', form.value.bgmFile)
  if (form.value.iconFile)      fd.append('icon_file', form.value.iconFile)
  for (const f of form.value.loadingBgFiles)   fd.append('loading_files', f)
  for (const f of form.value.containerBgFiles) fd.append('container_bg_files', f)

  try {
    const res = await fetch('/api/build', { method:'POST', body:fd })
    if (!res.ok) throw new Error(`Server error: ${res.status}`)
    const { task_id } = await res.json()
    emit('submitted', { taskId: task_id, edition: form.value.edition })
  } catch(e) {
    alert('Connection error: ' + e.message)
    submitting.value = false
  }
}
</script>

<style scoped>
.build-form { display: flex; flex-direction: column; }

/* ── Tab bar ───────────────────────────────────────────────────────────── */
.tab-bar {
  display: flex; justify-content: space-between;
  padding: 0 20px;
  border-bottom: 1px solid var(--border);
  background: var(--bg3);
}
.tab-group { display: flex; }

.tab {
  background: transparent;
  border: none; border-bottom: 2px solid transparent;
  color: var(--text3);
  cursor: pointer; font-family: var(--font);
  font-size: 0.82rem; font-weight: 500;
  padding: 12px 14px;
  white-space: nowrap;
}
.tab:hover:not(:disabled) { color: var(--text2); }
.tab.active { color: var(--accent); border-bottom-color: var(--accent); font-weight: 600; }
.tab:disabled { opacity: 0.4; cursor: not-allowed; }

/* ── Form body ─────────────────────────────────────────────────────────── */
.form-body { padding: 0; }

.form-section { border-bottom: 1px solid var(--border); padding-bottom: 10px; }
.form-section:last-child { border-bottom: none; }

.section-title {
  font-size: 0.65rem; font-weight: 700;
  letter-spacing: 0.08em; text-transform: uppercase;
  color: var(--text3);
  padding: 14px 20px 6px;
}

/* ── Field rows ────────────────────────────────────────────────────────── */
.field-row {
  display: grid;
  grid-template-columns: 170px 1fr;
  align-items: center;
  gap: 12px;
  padding: 5px 20px;
  min-height: 36px;
}

label {
  font-size: 0.8rem; font-weight: 500;
  color: var(--text2);
  white-space: nowrap;
  text-transform: none; letter-spacing: 0;
}
.hint { font-size: 0.7rem; color: var(--text3); font-weight: 400; }

/* ── Inputs ────────────────────────────────────────────────────────────── */
input[type="text"],
input[type="url"],
input[type="number"],
input.input-readonly,
select {
  background: var(--bg-input);
  border: 1px solid var(--border2);
  border-radius: var(--radius);
  color: var(--text);
  font-family: var(--font);
  font-size: 0.85rem;
  padding: 6px 10px;
  width: 100%;
  outline: none;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
  box-shadow: var(--shadow-sm);
  -webkit-appearance: none;
  appearance: none;
}
input:focus-visible, select:focus-visible,
input:focus, select:focus {
  border-color: var(--border-focus);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent) 15%, transparent);
}
input:disabled, select:disabled { opacity: 0.5; cursor: not-allowed; background: var(--bg3); }
input.input-readonly { cursor: pointer; }
input.mono { font-family: var(--mono); font-size: 0.8rem; }
input.input-short { max-width: 90px; }

select {
  cursor: pointer;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%2394a3b8' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 10px center;
  padding-right: 28px;
}
option { background: var(--bg-input); }

/* ── Input group ───────────────────────────────────────────────────────── */
.input-group { display: flex; align-items: center; gap: 6px; width: 100%; }
.input-group input, .input-group .input-info { flex: 1; min-width: 0; }

.input-info {
  font-size: 0.82rem; color: var(--text2);
  padding: 6px 10px;
  background: var(--bg3); border: 1px solid var(--border2);
  border-radius: var(--radius); box-shadow: var(--shadow-sm);
}

/* ── Buttons ───────────────────────────────────────────────────────────── */
.btn-side {
  background: var(--bg3);
  border: 1px solid var(--border2);
  border-radius: var(--radius);
  color: var(--text2);
  cursor: pointer; font-family: var(--font);
  font-size: 0.78rem; font-weight: 500;
  padding: 6px 12px; white-space: nowrap;
  flex-shrink: 0; box-shadow: var(--shadow-sm);
}
.btn-side:hover:not(:disabled) {
  border-color: var(--accent);
  color: var(--accent);
  background: var(--accent-light);
}
.btn-side:disabled { opacity: 0.4; cursor: not-allowed; }

.btn-icon-clear {
  background: transparent; border: 1px solid var(--border2);
  border-radius: var(--radius); color: var(--text3);
  cursor: pointer; font-size: 0.7rem; padding: 6px 8px;
  flex-shrink: 0;
}
.btn-icon-clear:hover:not(:disabled) {
  color: var(--red); border-color: var(--red);
  background: color-mix(in srgb, var(--red) 8%, transparent);
}
.btn-icon-clear:disabled { opacity: 0.3; cursor: not-allowed; }

/* ── Pack icon preview ─────────────────────────────────────────────────── */
.icon-field-group { position: relative; }
.icon-thumb {
  position: absolute; left: 9px; top: 50%; transform: translateY(-50%);
  width: 20px; height: 20px; border-radius: 3px; object-fit: cover;
  border: 1px solid var(--border2); pointer-events: none; z-index: 1;
}
.has-icon { padding-left: 34px !important; }

/* ── Radio group ───────────────────────────────────────────────────────── */
.radio-group { display: flex; gap: 18px; align-items: center; flex-wrap: wrap; }
.radio-opt {
  display: flex; align-items: center; gap: 6px;
  cursor: pointer; font-size: 0.83rem; color: var(--text2); user-select: none;
}
.radio-opt input[type="radio"] {
  width: 15px; height: 15px;
  accent-color: var(--accent); cursor: pointer; flex-shrink: 0;
  background: unset; border: unset; border-radius: unset; padding: unset; box-shadow: none;
}
.radio-opt:has(input:checked) span { color: var(--text); font-weight: 500; }

/* ── Version inputs ────────────────────────────────────────────────────── */
.version-group { display: flex; align-items: center; gap: 4px; }
.ver-input { width: 58px !important; text-align: center; padding: 6px 4px !important; }
.ver-sep { color: var(--text3); font-size: 1.1rem; font-weight: 500; line-height: 1; }

/* ── Computed value ────────────────────────────────────────────────────── */
.computed-value {
  font-family: var(--mono); font-size: 0.85rem;
  color: var(--accent); font-weight: 600;
  background: var(--accent-light);
  border: 1px solid color-mix(in srgb, var(--accent) 20%, transparent);
  border-radius: 6px; padding: 3px 10px; display: inline-block;
}

/* ── Loading BG thumbnail strip ───────────────────────────────────────────── */
.loading-strip {
  padding: 6px 20px 10px;
  display: flex; align-items: center; flex-wrap: wrap; gap: 6px;
}
.strip-thumb {
  position: relative; width: 48px; height: 48px;
  border: 1px solid var(--border2); border-radius: 6px;
  overflow: hidden; background: var(--bg3);
  box-shadow: var(--shadow-sm);
}
.strip-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; }
.strip-num {
  position: absolute; bottom: 2px; right: 3px;
  font-family: var(--mono); font-size: 0.58rem; font-weight: 700;
  background: rgba(0,0,0,0.55); color: #fff;
  border-radius: 3px; padding: 1px 4px; line-height: 1.3;
}
.strip-edit {
  background: var(--bg3); border: 1px dashed var(--border2);
  border-radius: 6px; color: var(--text3);
  font-family: var(--font); font-size: 0.73rem; font-weight: 500;
  padding: 4px 10px; cursor: pointer; height: 48px;
}
.strip-edit:hover:not(:disabled) {
  border-color: var(--accent); color: var(--accent); background: var(--accent-light);
}
.strip-edit:disabled { opacity: 0.4; cursor: not-allowed; }

/* ── Submit footer ─────────────────────────────────────────────────────── */
.form-footer {
  padding: 18px 20px;
  display: flex; flex-direction: column;
  align-items: flex-start; gap: 8px;
  background: var(--bg3);
  border-top: 1px solid var(--border);
}

.btn-build {
  background: var(--accent);
  border: none; border-radius: var(--radius);
  color: #fff; cursor: pointer;
  display: inline-flex; align-items: center; gap: 8px;
  font-family: var(--font); font-size: 0.88rem; font-weight: 600;
  padding: 9px 22px;
  box-shadow: 0 1px 2px rgba(99,102,241,0.3), 0 0 0 1px rgba(99,102,241,0.2);
  transition:
    background 0.15s ease,
    box-shadow 0.2s ease,
    transform 0.12s ease,
    outline 0.2s ease,
    outline-offset 0.2s ease;
}
.btn-build:hover:not(:disabled) {
  background: var(--accent-hover);
  box-shadow: 0 4px 12px rgba(99,102,241,0.35), 0 0 0 1px rgba(99,102,241,0.3);
  transform: translateY(-1px);
}
.btn-build:active:not(:disabled) { transform: translateY(0) scale(0.98); }
.btn-build:disabled { opacity: 0.5; cursor: not-allowed; box-shadow: none; }
.btn-sub { font-size: 0.73rem; opacity: 0.8; font-weight: 400; }

.btn-building { display: flex; align-items: center; gap: 8px; }
.spinner {
  width: 13px; height: 13px;
  border: 2px solid rgba(255,255,255,0.3);
  border-top-color: #fff; border-radius: 50%;
  animation: spin 0.7s linear infinite; display: inline-block;
}
@keyframes spin { to { transform: rotate(360deg); } }
.validation-hint { font-size: 0.78rem; color: var(--red); }
.ext-badge {
  background: var(--accent-light);
  border: 1px solid color-mix(in srgb, var(--accent) 25%, transparent);
  border-radius: 6px;
  color: var(--accent);
  font-family: var(--mono);
  font-size: 0.75rem;
  font-weight: 600;
  padding: 4px 10px;
  flex-shrink: 0;
  white-space: nowrap;
}
.debug-toast {
  position: fixed;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  background: var(--bg2);
  border: 1px solid var(--border2);
  border-left: 3px solid var(--accent);
  border-radius: var(--radius);
  box-shadow: var(--shadow-md);
  color: var(--text2);
  font-family: var(--mono);
  font-size: 0.75rem;
  padding: 8px 16px;
  z-index: 9999;
  white-space: nowrap;
  pointer-events: none;
}
.debug-toast-enter-active, .debug-toast-leave-active { transition: opacity 0.2s, transform 0.2s; }
.debug-toast-enter-from, .debug-toast-leave-to { opacity: 0; transform: translateX(-50%) translateY(8px); }
.field-note {
  font-size: 0.75rem; color: var(--amber);
  line-height: 1.5;
}
</style>
