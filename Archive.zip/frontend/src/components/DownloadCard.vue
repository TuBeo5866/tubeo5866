<template>
  <div class="download-card" :class="error ? 'state-error' : 'state-success'">
    <!-- Success -->
    <template v-if="!error">
      <div class="dc-icon success-icon">✓</div>
      <div class="dc-body">
        <p class="dc-title">.{{ fileExt }} is ready!</p>
        <p class="dc-sub">File will be deleted from server after download</p>
      </div>
      <div class="dc-actions">
        <a
          :href="`/api/download/${taskId}`"
          class="btn-download"
          download
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
          Download
        </a>
        <button type="button" class="btn-reset" @click="$emit('reset')">
          New pack
        </button>
      </div>
    </template>

    <!-- Error -->
    <template v-else>
      <div class="dc-icon error-icon">✕</div>
      <div class="dc-body">
        <p class="dc-title">Build failed</p>
        <p class="dc-sub">Check Build Log for more info</p>
      </div>
      <div class="dc-actions">
        <button type="button" class="btn-reset" @click="$emit('reset')">
          Try again
        </button>
      </div>
    </template>
  </div>
</template>

<script setup>
defineProps({
  taskId:   { type: String, default: null },
  error:    { type: String, default: null },
  fileExt:  { type: String, default: 'mcpack' },
})
defineEmits(['reset'])
</script>

<style scoped>
.download-card {
  border-radius: var(--radius-lg);
  padding: 16px 18px;
  display: flex; align-items: center; gap: 14px;
  animation: slideUp 0.22s ease both;
  box-shadow: var(--shadow);
}
@keyframes slideUp {
  from { opacity: 0; transform: translateY(6px); }
  to   { opacity: 1; transform: translateY(0); }
}

.state-success {
  background: color-mix(in srgb, var(--green) 8%, var(--bg2));
  border: 1px solid color-mix(in srgb, var(--green) 25%, transparent);
}
.state-error {
  background: color-mix(in srgb, var(--red) 6%, var(--bg2));
  border: 1px solid color-mix(in srgb, var(--red) 20%, transparent);
}

.dc-icon {
  width: 36px; height: 36px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 0.95rem; font-weight: 700; flex-shrink: 0;
}
.success-icon {
  background: color-mix(in srgb, var(--green) 15%, transparent);
  color: var(--green);
}
.error-icon {
  background: color-mix(in srgb, var(--red) 12%, transparent);
  color: var(--red);
}

.dc-body { flex: 1; min-width: 0; }
.dc-title { font-size: 0.85rem; font-weight: 600; margin-bottom: 2px; }
.state-success .dc-title { color: var(--green); }
.state-error   .dc-title { color: var(--red); }
.dc-sub { font-size: 0.75rem; color: var(--text3); }
.dc-error-msg { color: var(--red); opacity: 0.75; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.dc-actions { display: flex; gap: 8px; flex-shrink: 0; }

.btn-download {
  display: inline-flex; align-items: center; gap: 6px;
  background: var(--green); color: #fff;
  border: none; border-radius: var(--radius);
  font-family: var(--font); font-size: 0.82rem; font-weight: 600;
  padding: 7px 16px; cursor: pointer; text-decoration: none;
  box-shadow: 0 1px 2px rgba(16,185,129,0.25);
  transition: background 0.15s ease, transform 0.12s ease, box-shadow 0.2s ease, outline 0.2s ease, outline-offset 0.2s ease;
}
.btn-download:hover {
  background: #059669;
  box-shadow: 0 4px 8px rgba(16,185,129,0.3);
  transform: translateY(-1px);
}
.btn-download:active { transform: translateY(0) scale(0.97); }

.btn-reset {
  background: var(--bg3); color: var(--text2);
  border: 1px solid var(--border2);
  border-radius: var(--radius); font-family: var(--font);
  font-size: 0.82rem; font-weight: 500; padding: 7px 14px; cursor: pointer;
}
.btn-reset:hover {
  border-color: var(--accent); color: var(--accent);
  background: var(--accent-light);
}
</style>