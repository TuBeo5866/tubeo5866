<template>
  <div class="settings-wrap" ref="wrapRef">
    <button class="btn-settings" @click="toggle" :class="{ active: open }">
      Settings
      <span class="caret">▾</span>
    </button>

    <Transition name="drop">
      <div v-if="open" class="dropdown" @click.stop>
        <div class="drop-section-title">Theme</div>

        <div class="theme-options">
          <button
            v-for="opt in themeOptions"
            :key="opt.value"
            class="theme-btn"
            :class="{ active: settings.theme === opt.value }"
            @click="setTheme(opt.value)"
          >
            <svg v-if="opt.value === 'system'" class="theme-icon" viewBox="0 0 20 20" fill="none">
              <rect x="3" y="3" width="14" height="12" rx="2" stroke="currentColor" stroke-width="1.5"/>
              <rect x="6" y="6" width="8" height="6" fill="currentColor" opacity="0.3"/>
              <path d="M10 16v3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
            <svg v-if="opt.value === 'light'" class="theme-icon" viewBox="0 0 20 20" fill="none">
              <circle cx="10" cy="10" r="4" stroke="currentColor" stroke-width="1.5"/>
              <path d="M10 2v2M10 16v2M2 10h2M16 10h2M4.93 4.93l1.41 1.41M13.66 13.66l1.41 1.41M4.93 15.07l1.41-1.41M13.66 6.34l1.41-1.41" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
            <svg v-if="opt.value === 'dark'" class="theme-icon" viewBox="0 0 20 20" fill="none">
              <path d="M17 10.5a7 7 0 01-10-5.5 7 7 0 017 7 7 0 013-1.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none"/>
            </svg>
            {{ opt.label }}
          </button>
        </div>

        <div class="drop-section-title">Options</div>

        <label class="drop-item">
          <input type="checkbox" v-model="settings.showBuildLogs" @change="save" />
          <span>Show build logs panel</span>
        </label>

        <label class="drop-item">
          <input type="checkbox" v-model="settings.debugLogs" @change="save" />
          <span>Show debug logs</span>
        </label>
      </div>
    </Transition>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, onBeforeUnmount } from 'vue'

const emit = defineEmits(['update:settings'])

const open    = ref(false)
const wrapRef = ref(null)

const STORAGE_KEY = 'ext_studio_settings'

const themeOptions = [
  { value: 'system', label: 'System' },
  { value: 'light', label: 'Light' },
  { value: 'dark',  label: 'Dark' },
]

const settings = reactive({
  theme:       'system',
  showBuildLogs: true,
  debugLogs:    false,
})

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) Object.assign(settings, JSON.parse(raw))
  } catch {}
  applyTheme()
}

function save() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(settings)) } catch {}
  applyTheme()
  emit('update:settings', { ...settings })
}

function setTheme(val) {
  settings.theme = val
  save()
}

function applyTheme() {
  const html = document.documentElement
  if (settings.theme === 'system') {
    html.removeAttribute('data-theme')
  } else {
    html.setAttribute('data-theme', settings.theme)
  }
}

function toggle() { open.value = !open.value }

function onOutsideClick(e) {
  if (wrapRef.value && !wrapRef.value.contains(e.target)) open.value = false
}

onMounted(() => {
  load()
  emit('update:settings', { ...settings })
  document.addEventListener('click', onOutsideClick)
})

onBeforeUnmount(() => document.removeEventListener('click', onOutsideClick))
</script>

<style scoped>
.settings-wrap { position: relative; }

.btn-settings {
  background: var(--bg3); border: 1px solid var(--border2);
  border-radius: var(--radius); color: var(--text2);
  cursor: pointer; font-family: var(--font);
  font-size: 0.82rem; font-weight: 500;
  padding: 6px 14px; display: flex; align-items: center; gap: 5px;
  box-shadow: var(--shadow-sm);
}
.btn-settings:hover,
.btn-settings.active { border-color: var(--accent); color: var(--accent); background: var(--accent-light); }
.caret { font-size: 0.65rem; opacity: 0.7; }

.dropdown {
  position: absolute; top: calc(100% + 6px); right: 0;
  background: var(--bg2); border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-md), 0 0 0 1px rgba(0,0,0,0.04);
  min-width: 210px; z-index: 200;
  padding: 6px 0 8px;
}

.drop-section-title {
  font-size: 0.65rem; font-weight: 700;
  letter-spacing: 0.08em; text-transform: uppercase;
  color: var(--text3); padding: 6px 14px 4px;
}

.theme-options {
  display: flex; gap: 4px;
  padding: 4px 10px 8px;
}
.theme-btn {
  flex: 1;
  display: flex; flex-direction: column; align-items: center; gap: 4px;
  background: var(--bg3); border: 1px solid var(--border2);
  border-radius: var(--radius); color: var(--text3);
  cursor: pointer; font-family: var(--font);
  font-size: 0.7rem; font-weight: 500;
  padding: 8px 6px;
  box-shadow: var(--shadow-sm);
}
.theme-btn:hover {
  border-color: var(--accent); color: var(--text2);
  background: var(--accent-light);
}
.theme-btn.active {
  border-color: var(--accent); color: var(--accent);
  background: var(--accent-light);
}

.theme-icon {
  width: 18px; height: 18px;
  flex-shrink: 0;
}

.drop-item {
  display: flex; align-items: center; gap: 10px;
  padding: 7px 14px; cursor: pointer;
  font-size: 0.82rem; color: var(--text2);
  transition: background 0.12s;
  user-select: none;
}
.drop-item:hover { background: var(--bg3); }
.drop-item input[type="checkbox"] {
  width: 14px;
  height: 14px;
  accent-color: var(--accent); cursor: pointer;
  flex-shrink: 0;
  background: unset; border: unset; border-radius: unset;
  padding: unset; box-shadow: none;
}
.drop-item:has(input:checked) span { color: var(--text); }

/* Transition */
.drop-enter-active, .drop-leave-active {
  transition: opacity 0.15s, transform 0.15s;
}
.drop-enter-from, .drop-leave-to {
  opacity: 0; transform: translateY(-6px);
}
</style>
