<template>
  <Transition name="modal">
    <Teleport to="body">
      <div class="modal-overlay" @click.self="cancel">
        <div class="modal">
          <div class="modal-header">
          <span>Custom Container Backgrounds</span>
          <button class="btn-close" @click="cancel">✕</button>
        </div>

        <div class="modal-body">
          <p class="hint-text">Optional — leave any field empty to use the default from the downloaded ZIP.</p>

          <div class="slots-panel">
            <div class="slots-list">
              <div
                v-for="slot in slots" :key="slot.key"
                class="slot-row"
                :class="{ active: activeSlot === slot.key }"
                @click="activeSlot = slot.key"
              >
                <span class="slot-label">{{ slot.label }}:</span>
                <input
                  class="slot-input"
                  :value="files[slot.key] ? files[slot.key].name : ''"
                  :placeholder="'(default)'"
                  readonly
                  @click.stop="triggerFile(slot.key)"
                />
                <div
                  class="slot-thumb"
                  :style="previews[slot.key] ? { backgroundImage: `url(${previews[slot.key]})` } : {}"
                ></div>
                <button type="button" class="btn-clear-sm" @click.stop="clearSlot(slot.key)" :disabled="!files[slot.key]">✕</button>
                <button type="button" class="btn-browse-sm" @click.stop="triggerFile(slot.key)">Browse...</button>
                <input
                  :ref="el => { if(el) fileInputs[slot.key] = el }"
                  type="file" accept="image/*" style="display:none"
                  @change="e => onFileChange(slot.key, e)"
                />
              </div>
            </div>

            <div class="preview-panel">
              <div class="preview-title">Preview</div>
              <div class="preview-area">
                <img
                  v-if="activeSlot && previews[activeSlot]"
                  :src="previews[activeSlot]"
                  alt="preview"
                />
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-cancel" @click="cancel">Cancel</button>
          <button type="button" class="btn-ok" @click="confirm">Apply</button>
        </div>
      </div>
    </div>
  </Teleport>
  </Transition>
</template>

<script setup>
import { ref, reactive, onBeforeUnmount } from 'vue'

const props = defineProps({
  modelValue: { type: Array, default: () => [] },
})
const emit = defineEmits(['update:modelValue', 'close'])

const SLOTS = [
  'Anvil','Beacon','Brewing','Cartography','Chest',
  'Enchanting','Furnace','Grindstone','Horse Inventory',
  'Player Inventory','Loom','Redstone Commons','Smithing','Stone Cutter',
]

const slots = SLOTS.map(s => ({ key: s, label: s }))

const files      = reactive({})
const previews   = reactive({})
const fileInputs = reactive({})
const activeSlot = ref(null)

// Init from modelValue if re-opened
for (const f of props.modelValue) {
  if (f._slot) {
    files[f._slot]    = f
    previews[f._slot] = URL.createObjectURL(f)
  }
}

function triggerFile(key) {
  fileInputs[key]?.click()
}

function onFileChange(key, e) {
  const f = e.target.files[0]
  if (!f) return
  if (previews[key]) URL.revokeObjectURL(previews[key])
  // tag file with slot name for parent
  Object.defineProperty(f, '_slot', { value: key, writable: false })
  files[key]    = f
  previews[key] = URL.createObjectURL(f)
  activeSlot.value = key
  e.target.value = ''
}

function clearSlot(key) {
  if (previews[key]) URL.revokeObjectURL(previews[key])
  delete files[key]
  delete previews[key]
  if (activeSlot.value === key) activeSlot.value = null
}

function confirm() {
  const result = Object.values(files).filter(Boolean)
  emit('update:modelValue', result)
  emit('close')
}
function cancel() { emit('close') }

onBeforeUnmount(() => {
  for (const url of Object.values(previews)) URL.revokeObjectURL(url)
})
</script>

<style scoped>
.modal-overlay {
  position: fixed; inset: 0;
  background: rgba(15,23,42,0.5);
  backdrop-filter: blur(4px);
  display: flex; align-items: center; justify-content: center; z-index: 1000;
}

.modal-enter-active { transition: opacity 0.25s ease; }
.modal-leave-active { transition: opacity 0.2s ease; }
.modal-enter-active .modal { transition: transform 0.25s ease, opacity 0.25s ease; }
.modal-leave-active .modal { transition: transform 0.15s ease, opacity 0.15s ease; }
.modal-enter-from, .modal-leave-to { opacity: 0; }
.modal-enter-from .modal { transform: scale(0.95) translateY(10px); opacity: 0; }
.modal-leave-to .modal { transform: scale(0.95); opacity: 0; }
.modal {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  box-shadow: 0 20px 40px rgba(0,0,0,0.15);
  width: 800px; max-width: 96vw; max-height: 88vh;
  display: flex; flex-direction: column;
}
.modal-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 18px; border-bottom: 1px solid var(--border);
  font-size: 0.88rem; font-weight: 600; flex-shrink: 0;
  background: var(--bg3);
  border-radius: var(--radius-lg) var(--radius-lg) 0 0;
}
.btn-close {
  background: none; border: none; color: var(--text3);
  cursor: pointer; font-size: 0.78rem; padding: 3px 7px; border-radius: 6px;
  transition: color 0.15s, background 0.15s;
}
.btn-close:hover { color: var(--red); background: color-mix(in srgb, var(--red) 8%, transparent); }

.modal-body { padding: 14px 18px; overflow: hidden; display: flex; flex-direction: column; gap: 10px; flex: 1; min-height: 0; }
.hint-text { font-size: 0.78rem; color: var(--text3); flex-shrink: 0; }

.slots-panel { display: flex; gap: 16px; flex: 1; min-height: 0; }
.slots-list {
  flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 3px;
  scrollbar-width: thin; scrollbar-color: var(--border2) transparent;
}

.slot-row {
  display: grid;
  grid-template-columns: 145px 1fr 28px 26px 76px;
  align-items: center; gap: 6px;
  padding: 5px 8px; border-radius: 8px; cursor: pointer;
  transition: background 0.12s;
}
.slot-row:hover  { background: var(--bg3); }
.slot-row.active { background: var(--accent-light); }

.slot-label { font-size: 0.8rem; color: var(--text2); white-space: nowrap; }
.slot-input {
  background: var(--bg-input); border: 1px solid var(--border2);
  border-radius: 6px; color: var(--text);
  font-size: 0.78rem; padding: 4px 8px; cursor: pointer;
  min-width: 0; box-shadow: var(--shadow-sm);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.slot-thumb {
  width: 28px; height: 28px;
  background: var(--bg3); border: 1px solid var(--border2);
  border-radius: 5px; background-size: cover; background-position: center;
  flex-shrink: 0;
}

.btn-clear-sm {
  background: none; border: 1px solid var(--border2);
  border-radius: 5px; color: var(--text3); cursor: pointer;
  font-size: 0.65rem; padding: 3px 5px; line-height: 1;
  transition: color 0.15s, border-color 0.15s;
}
.btn-clear-sm:hover:not(:disabled) { color: var(--red); border-color: var(--red); }
.btn-clear-sm:disabled { opacity: 0.3; cursor: not-allowed; }

.btn-browse-sm {
  background: var(--bg3); border: 1px solid var(--border2);
  border-radius: 6px; color: var(--text2); cursor: pointer;
  font-family: var(--font); font-size: 0.75rem; font-weight: 500;
  padding: 4px 10px; white-space: nowrap;
  transition: border-color 0.15s, color 0.15s, background 0.15s;
}
.btn-browse-sm:hover { border-color: var(--accent); color: var(--accent); background: var(--accent-light); }

.preview-panel { width: 220px; flex-shrink: 0; display: flex; flex-direction: column; gap: 8px; }
.preview-title {
  font-size: 0.65rem; font-weight: 700; letter-spacing: 0.08em;
  text-transform: uppercase; color: var(--text3); text-align: center;
}
.preview-area {
  flex: 1; background: var(--bg3); border: 1px solid var(--border2);
  border-radius: 10px; overflow: hidden;
  display: flex; align-items: center; justify-content: center; min-height: 180px;
  box-shadow: var(--shadow-sm) inset;
}
.preview-area img { max-width: 100%; max-height: 100%; object-fit: contain; }

.modal-footer {
  display: flex; justify-content: flex-end; gap: 8px;
  padding: 12px 18px; border-top: 1px solid var(--border); flex-shrink: 0;
  background: var(--bg3);
  border-radius: 0 0 var(--radius-lg) var(--radius-lg);
}
.btn-cancel, .btn-ok {
  border-radius: var(--radius); font-family: var(--font);
  font-size: 0.82rem; font-weight: 500; padding: 7px 20px; cursor: pointer;
}
.btn-cancel { background: var(--bg-input); border: 1px solid var(--border2); color: var(--text2); }
.btn-cancel:hover { border-color: var(--accent); color: var(--accent); background: var(--accent-light); }
.btn-ok { background: var(--accent); border: none; color: #fff; box-shadow: 0 1px 2px rgba(99,102,241,0.3); }
.btn-ok:hover { background: var(--accent-hover); }
</style>
