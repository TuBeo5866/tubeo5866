<template>
  <div class="progress-panel">
    <div class="pp-header">
      <h2>Build Output</h2>
      <div class="pp-status">
        <span class="status-dot" :class="statusClass"></span>
        <span class="status-text">{{ statusLabel }}</span>
      </div>
    </div>

    <!-- Idle state -->
    <div v-if="!taskId && !isBuilding" class="pp-idle">
      <div class="idle-icon">⬡</div>
      <p>Fill in the form and click <strong>Build Pack</strong> to get started</p>
    </div>

    <!-- Active / done state -->
    <template v-else>
      <!-- Progress bar -->
      <div class="pp-progress-wrap">
        <div class="pp-progress-bar">
          <div
            class="pp-progress-fill"
            :style="{ width: progress + '%' }"
            :class="{ done: !isBuilding && !error }"
          ></div>
        </div>
        <span class="pp-progress-pct">{{ progress }}%</span>
      </div>

      <!-- Log output -->
      <div class="pp-log" ref="logEl">
        <div
          v-for="(line, i) in logs"
          :key="i"
          class="log-line"
          :class="getLineClass(line)"
        >
          <span class="log-prefix">›</span>
          <span class="log-text">{{ line }}</span>
        </div>
        <div v-if="isBuilding" class="log-line log-cursor">
          <span class="log-prefix">›</span>
          <span class="cursor-blink">▊</span>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref, computed, watch, nextTick, onUnmounted } from 'vue'

const props = defineProps({
  taskId:     { type: String, default: null },
  isBuilding: { type: Boolean, default: false },
})

const emit = defineEmits(['done', 'error'])

const logs     = ref([])
const progress = ref(0)
const error    = ref(null)
const logEl    = ref(null)

let sse = null

const statusClass = computed(() => {
  if (!props.taskId && !props.isBuilding) return 'idle'
  if (props.isBuilding) return 'building'
  if (error.value) return 'error'
  return 'done'
})

const statusLabel = computed(() => {
  if (!props.taskId && !props.isBuilding) return 'Idle'
  if (props.isBuilding) return 'Building…'
  if (error.value) return 'Failed'
  return 'Done'
})

watch(() => props.taskId, (id) => {
  if (!id) return
  logs.value = []
  progress.value = 0
  error.value = null
  startSSE(id)
})

function startSSE(taskId) {
  if (sse) { sse.close(); sse = null }

  sse = new EventSource(`/api/progress/${taskId}`)

  sse.addEventListener('log', (e) => {
    const data = JSON.parse(e.data)
    logs.value.push(data.message)
    scrollToBottom()
  })

  sse.addEventListener('progress', (e) => {
    const data = JSON.parse(e.data)
    progress.value = data.value
  })

  sse.addEventListener('done', (e) => {
    const data = JSON.parse(e.data)
    sse.close()
    sse = null
    if (data.success) {
      progress.value = 100
      logs.value.push('✅ Build completed successfully!')
      emit('done')
    } else {
      error.value = data.message
      logs.value.push('❌ ' + data.message)
      emit('error', data.message)
    }
  })

  sse.onerror = () => {
    if (sse?.readyState === EventSource.CLOSED) return
    sse.close()
    sse = null
    const msg = 'SSE connection lost'
    error.value = msg
    logs.value.push('⚠️ ' + msg)
    emit('error', msg)
  }
}

async function scrollToBottom() {
  await nextTick()
  if (logEl.value) {
    logEl.value.scrollTop = logEl.value.scrollHeight
  }
}

function getLineClass(line) {
  if (line.startsWith('✅') || line.includes('successfully')) return 'log-success'
  if (line.startsWith('❌') || line.includes('Error') || line.includes('failed')) return 'log-error'
  if (line.startsWith('⚠️') || line.includes('Warning') || line.includes('WARN')) return 'log-warn'
  if (line.startsWith('[') && line.includes(']')) return 'log-tag'
  return ''
}

onUnmounted(() => { if (sse) sse.close() })
</script>

<style scoped>
.progress-panel { display: flex; flex-direction: column; min-height: 280px; }

.pp-header {
  padding: 16px 20px 12px;
  border-bottom: 1px solid var(--border);
  display: flex; align-items: center; justify-content: space-between;
  background: var(--bg3);
}
.pp-header h2 { font-size: 0.88rem; font-weight: 600; color: var(--text); }

.pp-status { display: flex; align-items: center; gap: 7px; }
.status-dot {
  width: 7px; height: 7px; border-radius: 50%;
  background: var(--border2); transition: background 0.3s;
}
.status-dot.building {
  background: var(--accent);
  animation: pulse 1.4s ease-in-out infinite;
}
.status-dot.done    { background: var(--green); }
.status-dot.error   { background: var(--red); }

@keyframes pulse {
  0%,100% { box-shadow: 0 0 0 0 color-mix(in srgb, var(--accent) 40%, transparent); }
  50%     { box-shadow: 0 0 0 6px color-mix(in srgb, var(--accent) 0%, transparent); }
}

.status-text { font-size: 0.75rem; font-weight: 500; color: var(--text3); }

.pp-idle {
  flex: 1; display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  gap: 10px; padding: 40px 28px; color: var(--text3);
}
.idle-icon { font-size: 2rem; opacity: 0.2; }
.pp-idle p { font-size: 0.82rem; text-align: center; line-height: 1.6; color: var(--text3); }
.pp-idle strong { color: var(--text2); }

.pp-progress-wrap {
  display: flex; align-items: center;
  gap: 10px; padding: 14px 20px 8px;
}
.pp-progress-bar {
  flex: 1; height: 5px;
  background: var(--border); border-radius: 999px; overflow: hidden;
}
.pp-progress-fill {
  height: 100%; background: var(--accent); border-radius: 999px;
  transition: width 0.4s ease; position: relative; overflow: hidden;
}
.pp-progress-fill::after {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.3) 50%, transparent 100%);
  animation: shimmer 1.5s linear infinite;
}
.pp-progress-fill.done { background: var(--green); }
.pp-progress-fill.done::after { display: none; }

@keyframes shimmer {
  from { transform: translateX(-100%); }
  to   { transform: translateX(100%); }
}

.pp-progress-pct {
  font-family: var(--mono); font-size: 0.72rem;
  color: var(--text3); min-width: 32px; text-align: right;
}

.pp-log {
  flex: 1; font-family: var(--mono); font-size: 0.73rem;
  line-height: 1.75; padding: 10px 16px 16px;
  max-height: 300px; overflow-y: auto;
  scrollbar-width: thin; scrollbar-color: var(--border2) transparent;
}
.pp-log::-webkit-scrollbar { width: 4px; }
.pp-log::-webkit-scrollbar-track { background: transparent; }
.pp-log::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 2px; }

.log-line {
  display: flex; gap: 8px; color: var(--text3);
  animation: fadeSlide 0.12s ease both;
}
@keyframes fadeSlide {
  from { opacity: 0; transform: translateY(3px); }
  to   { opacity: 1; transform: translateY(0); }
}
.log-prefix { color: var(--border2); flex-shrink: 0; }
.log-success .log-text { color: var(--green); }
.log-error   .log-text { color: var(--red); }
.log-warn    .log-text { color: var(--amber); }
.log-tag     .log-text { color: var(--accent); }

.log-cursor { opacity: 0.5; }
.cursor-blink { animation: blink 1s step-end infinite; }
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
</style>
