<template>
  <Transition name="banner">
    <div
      v-if="visible && text"
      ref="bannerEl"
      class="banner"
    >
      <span class="banner-icon">📢</span>
      <span class="banner-text">{{ text }}</span>
      <button class="banner-close" @click.stop="dismiss" title="Dismiss">✕</button>
    </div>
  </Transition>
</template>

<script setup>
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'

const FETCH_URL  = 'https://tubeo5866.github.io/banner.txt'
const COUNTDOWN  = 10   // seconds
const THRESHOLD  = 55   // px drag threshold to dismiss

const text    = ref('')
const visible = ref(false)

// ── Countdown ───────────────────────────────────────────────────────────────
let _countdown = COUNTDOWN
let _timer = null
let _hovered = false

function startTimer() {
  if (_timer) return
  _timer = setInterval(() => {
    if (_hovered || isDragging.value) return
    _countdown--
    if (_countdown <= 0) dismiss()
  }, 1000)
}

function stopTimer() {
  clearInterval(_timer); _timer = null
}

// ── Dismiss ─────────────────────────────────────────────────────────────────
function dismiss() {
  stopTimer()
  visible.value = false
}

// ── Hover pause ─────────────────────────────────────────────────────────────
const bannerEl = ref(null)

function onMouseEnter() { _hovered = true; stopTimer() }
function onMouseLeave() { _hovered = false; startTimer() }

// ── Fetch ────────────────────────────────────────────────────────────────────
onMounted(async () => {
  try {
    const res = await fetch(FETCH_URL)
    if (!res.ok) return
    const t = (await res.text()).trim()
    if (!t) return
    text.value   = t
    visible.value = true
    startTimer()
  } catch {}

  // Attach hover listeners after mount
  const el = bannerEl.value?.$el ?? bannerEl.value
  if (el) {
    el.addEventListener('mouseenter', onMouseEnter)
    el.addEventListener('mouseleave', onMouseLeave)
  }
})

onBeforeUnmount(() => {
  stopTimer()
})
</script>

<style scoped>
.banner {
  position: fixed;
  top: 62px;
  right: 20px;
  width: min(420px, 38vw);
  min-width: 220px;
  z-index: 500;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 10px 10px 14px;
  border-radius: 12px;
  background: linear-gradient(90deg, #0d1b4b 0%, #005f73 100%);
  border: 1px solid #00b4d8;
  box-shadow: 0 4px 20px rgba(0,180,216,0.2), 0 2px 8px rgba(0,0,0,0.3);
}

.banner-icon {
  font-size: 14px;
  flex-shrink: 0;
  line-height: 1;
}

.banner-text {
  flex: 1;
  font-size: 0.78rem;
  font-weight: 600;
  color: #fff;
  line-height: 1.4;
  min-width: 0;
  word-break: break-word;
}

.banner-close {
  width: 22px; height: 22px;
  background: rgba(255,255,255,0.12);
  border: none;
  border-radius: 50%;
  color: rgba(255,255,255,0.8);
  font-size: 10px;
  font-weight: 700;
  cursor: pointer;
  flex-shrink: 0;
  display: flex; align-items: center; justify-content: center;
  transition: background 0.15s, color 0.15s;
  line-height: 1;
}
.banner-close:hover { background: rgba(255,255,255,0.28); color: #fff; }

/* Transition */
.banner-enter-active { transition: opacity 0.3s, transform 0.3s cubic-bezier(0.34,1.56,0.64,1); }
.banner-leave-active { transition: opacity 0.25s, transform 0.25s ease-in; }
.banner-enter-from   { opacity: 0; transform: translateY(-16px) scale(0.95); }
.banner-leave-to     { opacity: 0; transform: translateY(-20px); }

@media (max-width: 600px) {
  .banner { right: 12px; width: calc(100vw - 24px); min-width: unset; border-radius: 14px; }
}
</style>