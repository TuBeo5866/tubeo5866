<template>
    <Transition name="modal">
      <Teleport to="body">
        <div class="modal-overlay" @click.self="cancel">
          <div class="modal">
  
          <div class="modal-header">
            <span>Loading Background — Set Order</span>
            <button class="btn-close" @click="cancel">✕</button>
          </div>
  
          <div class="modal-body">
            <p class="hint">
              Drag to reorder. Images will be renamed
              <code>1, 2, 3…</code> in this order when building.
            </p>
  
            <!-- Upload zone (always visible to add more) -->
            <div
              class="upload-zone"
              :class="{ dragging: isDraggingFile }"
              @click="$refs.addInput.click()"
              @dragover.prevent="isDraggingFile = true"
              @dragleave.prevent="isDraggingFile = false"
              @drop.prevent="onDrop"
            >
              <input
                ref="addInput"
                type="file"
                accept="image/*"
                multiple
                style="display:none"
                @change="onAddFiles"
              />
              <span class="upload-icon">↑</span>
              <span>{{ isDraggingFile ? 'Drop here' : 'Click or drag to add more images' }}</span>
            </div>
  
            <!-- Image grid -->
            <div v-if="items.length" class="img-grid">
              <div
                v-for="(item, i) in items"
                :key="item.id"
                class="img-item"
                :class="{ 'drag-over': dragOverIdx === i, 'dragging-item': dragSrcIdx === i }"
                draggable="true"
                @dragstart="onDragStart(i)"
                @dragover.prevent="dragOverIdx = i"
                @dragleave="dragOverIdx = null"
                @drop.prevent="onDragDrop(i)"
                @dragend="dragOverIdx = null; dragSrcIdx = null"
              >
                <img :src="item.url" :alt="item.name" />
                <div class="img-overlay">
                  <span class="img-num">{{ i + 1 }}</span>
                  <button class="img-del" type="button" @click.stop="remove(i)">✕</button>
                </div>
                <div class="img-name">{{ item.name }}</div>
              </div>
            </div>
  
            <p v-else class="empty-hint">No images added yet.</p>
          </div>
  
          <div class="modal-footer">
            <span class="footer-count">{{ items.length }} image{{ items.length !== 1 ? 's' : '' }}</span>
            <div class="footer-actions">
              <button type="button" class="btn-cancel" @click="cancel">Cancel</button>
              <button type="button" class="btn-ok" :disabled="!items.length" @click="confirm">
                Apply Order
              </button>
            </div>
          </div>
  
        </div>
      </div>
    </Teleport>
  </Transition>
  </template>
  
  <script setup>
  import { ref, onBeforeUnmount } from 'vue'
  
  const props = defineProps({
    // initial files already selected
    modelValue: { type: Array, default: () => [] },
  })
  const emit = defineEmits(['update:modelValue', 'close'])
  
  // Internal item list: { id, file, url, name }
  let _idCounter = 0
  function makeItem(file) {
    return { id: ++_idCounter, file, url: URL.createObjectURL(file), name: file.name }
  }
  
  const items = ref(props.modelValue.map(f => makeItem(f)))
  
  const isDraggingFile = ref(false)
  const dragSrcIdx     = ref(null)
  const dragOverIdx    = ref(null)
  
  // ── Add files ──────────────────────────────────────────────────────────────
  function addFiles(fileList) {
    for (const f of fileList) {
      if (f.type.startsWith('image/')) items.value.push(makeItem(f))
    }
  }
  
  function onAddFiles(e) {
    addFiles(e.target.files)
    e.target.value = ''
  }
  
  function onDrop(e) {
    isDraggingFile.value = false
    addFiles(e.dataTransfer.files)
  }
  
  // ── Remove ─────────────────────────────────────────────────────────────────
  function remove(i) {
    URL.revokeObjectURL(items.value[i].url)
    items.value.splice(i, 1)
  }
  
  // ── Drag-to-reorder ────────────────────────────────────────────────────────
  function onDragStart(i) { dragSrcIdx.value = i }
  
  function onDragDrop(i) {
    if (dragSrcIdx.value === null || dragSrcIdx.value === i) return
    const arr  = [...items.value]
    const [item] = arr.splice(dragSrcIdx.value, 1)
    arr.splice(i, 0, item)
    items.value  = arr
    dragOverIdx.value = null
  }
  
  // ── Confirm / cancel ───────────────────────────────────────────────────────
  function confirm() {
    emit('update:modelValue', items.value.map(it => it.file))
    emit('close')
  }
  
  function cancel() { emit('close') }
  
  onBeforeUnmount(() => {
    for (const it of items.value) URL.revokeObjectURL(it.url)
  })
  </script>
  
<style scoped>
.modal-overlay {
  position: fixed; inset: 0;
  background: rgba(15,23,42,0.5);
  backdrop-filter: blur(4px);
  display: flex; align-items: center; justify-content: center;
  z-index: 1000;
}

.modal-enter-active { transition: opacity 0.25s ease; }
.modal-leave-active { transition: opacity 0.2s ease; }
.modal-enter-active .modal { transition: transform 0.25s ease, opacity 0.25s ease; }
.modal-leave-active .modal { transition: transform 0.15s ease, opacity 0.15s ease; }
.modal-enter-from, .modal-leave-to { opacity: 0; }
.modal-enter-from .modal { transform: scale(0.95) translateY(10px); opacity: 0; }
.modal-leave-to .modal { transform: scale(0.95); opacity: 0; }

.modal {
    background: var(--bg2);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    box-shadow: 0 20px 40px rgba(0,0,0,0.15);
    width: 640px; max-width: 96vw; max-height: 88vh;
    display: flex; flex-direction: column;
  }
  
  .modal-header {
    display: flex; align-items: center; justify-content: space-between;
    padding: 14px 18px; border-bottom: 1px solid var(--border);
    font-size: 0.88rem; font-weight: 600;
    background: var(--bg3);
    border-radius: var(--radius-lg) var(--radius-lg) 0 0;
    flex-shrink: 0;
  }
  .btn-close {
    background: none; border: none; color: var(--text3);
    cursor: pointer; font-size: 0.78rem; padding: 3px 7px; border-radius: 6px;
    transition: color 0.15s, background 0.15s;
  }
  .btn-close:hover { color: var(--red); background: color-mix(in srgb, var(--red) 8%, transparent); }
  
  .modal-body {
    padding: 16px 18px;
    overflow-y: auto; flex: 1;
    display: flex; flex-direction: column; gap: 14px;
    scrollbar-width: thin; scrollbar-color: var(--border2) transparent;
  }
  
  .hint {
    font-size: 0.78rem; color: var(--text3); line-height: 1.5;
  }
  .hint code {
    font-family: var(--mono); font-size: 0.75rem;
    background: var(--bg3); border: 1px solid var(--border2);
    border-radius: 4px; padding: 1px 5px;
  }
  
  /* ── Upload zone ─────────────────────────────────────────────────────────── */
  .upload-zone {
    border: 1.5px dashed var(--border2);
    border-radius: var(--radius);
    background: var(--bg3);
    padding: 14px;
    display: flex; align-items: center; justify-content: center;
    gap: 8px; cursor: pointer;
    font-size: 0.82rem; color: var(--text3);
    transition: border-color 0.15s, background 0.15s, color 0.15s;
    flex-shrink: 0;
  }
  .upload-zone:hover,
  .upload-zone.dragging {
    border-color: var(--accent);
    background: var(--accent-light);
    color: var(--accent);
  }
  .upload-icon { font-size: 1rem; font-weight: 600; }
  
  /* ── Image grid ──────────────────────────────────────────────────────────── */
  .img-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
    gap: 10px;
  }
  
  .img-item {
    position: relative;
    border: 1.5px solid var(--border2);
    border-radius: 8px; overflow: hidden;
    cursor: grab; background: var(--bg3);
    box-shadow: var(--shadow-sm);
    transition: box-shadow 0.15s, border-color 0.15s, opacity 0.15s;
    user-select: none;
  }
  .img-item:hover { box-shadow: var(--shadow-md); }
  .img-item:active { cursor: grabbing; }
  .img-item.drag-over { border-color: var(--accent); box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent) 20%, transparent); }
  .img-item.dragging-item { opacity: 0.4; }
  
  .img-item img {
    width: 100%; aspect-ratio: 1/1;
    object-fit: cover; display: block;
  }
  
  .img-overlay {
    position: absolute; top: 0; left: 0; right: 0;
    display: flex; justify-content: space-between; align-items: flex-start;
    padding: 4px;
  }
  .img-num {
    background: rgba(0,0,0,0.55); color: #fff;
    font-family: var(--mono); font-size: 0.65rem; font-weight: 700;
    border-radius: 4px; padding: 2px 6px; line-height: 1.4;
  }
  .img-del {
    background: rgba(0,0,0,0.5); border: none; color: #fff;
    font-size: 0.6rem; border-radius: 4px; padding: 2px 5px;
    cursor: pointer; opacity: 0;
    transition: opacity 0.15s, background 0.15s;
    line-height: 1.4;
  }
  .img-item:hover .img-del { opacity: 1; }
  .img-del:hover { background: var(--red); }
  
  .img-name {
    padding: 4px 6px;
    font-size: 0.65rem; color: var(--text3);
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    background: var(--bg3); border-top: 1px solid var(--border);
  }
  
  .empty-hint { font-size: 0.8rem; color: var(--text3); text-align: center; padding: 24px 0; }
  
  /* ── Footer ──────────────────────────────────────────────────────────────── */
  .modal-footer {
    display: flex; align-items: center; justify-content: space-between;
    padding: 12px 18px; border-top: 1px solid var(--border);
    background: var(--bg3);
    border-radius: 0 0 var(--radius-lg) var(--radius-lg);
    flex-shrink: 0;
  }
  .footer-count { font-size: 0.78rem; color: var(--text3); }
  .footer-actions { display: flex; gap: 8px; }
  
  .btn-cancel, .btn-ok {
    border-radius: var(--radius); font-family: var(--font);
    font-size: 0.82rem; font-weight: 500; padding: 7px 18px; cursor: pointer;
  }
  .btn-cancel { background: var(--bg-input); border: 1px solid var(--border2); color: var(--text2); }
  .btn-cancel:hover { border-color: var(--accent); color: var(--accent); background: var(--accent-light); }
  .btn-ok {
    background: var(--accent); border: none; color: #fff;
    box-shadow: 0 1px 2px rgba(99,102,241,0.3);
    transition: background 0.15s;
  }
  .btn-ok:hover:not(:disabled) { background: var(--accent-hover); }
  .btn-ok:disabled { opacity: 0.4; cursor: not-allowed; }
  </style>